# OnPoint Installer Portal

Mobile-first installer website built against the provided CRM API documentation.

## What It Includes

- Secure login flow with conditional 2FA input.
- Customer selection from permitted customer list.
- Role-aware device handling:
  - Admin: choose new install or check existing device; searchable device list per selected mode.
  - Technician: IMEI-only lookup.
- Vehicle details capture (licence plate and VIN).
- Device status checks for GPS and fuel data.
- Admin existing-device status checks for already installed/client devices.
- Tacho test execution via API.
- Final validation and complete install action (then returns to step 3).

## Security Approach

- CRM API requests run server-to-server through `server.js`.
- Browser never receives CRM bearer token.
- Session cookie is `httpOnly` and `sameSite=strict`.
- Rate limiting is applied to API and login routes.
- Origin allowlist check is enforced on `/api/*` routes.
- Passwords are never stored in local storage.

## Setup

1. Install dependencies:

```bash
npm install
```

2. Create `.env` from `.env.example` and set values:

- `CRM_API_BASE_URL` should point to your CRM API base URL (for example `https://your-host/crm-api`).
- `SESSION_SECRET` should be a long random value.
- `ALLOWED_ORIGINS` should include your frontend origin.

3. Start the app:

```bash
npm run start
```

4. Open:

`http://localhost:3000`

## Generated Docs

- Rebuild endpoint mapping with `npm run docs:endpoints`.
- `endpoint-categories.md` is generated output and should not be manually edited.

## Frontend Module Structure

The frontend remains plain JavaScript and now uses small modules under `public/js/`:

- `api.js`: shared API request helper.
- `utils.js`: URL/path and response parsing helpers (keeps fetch paths working when hosted in a subfolder, such as GoDaddy deployments).
- `state.js`: flow constants and initial-state factories.
- `roles.js`: account/role normalization helpers.
- `install-form.js`: install field metadata and required-field checks.
- `install-validation.js`: step-3 field validation helpers and invalid-state reset utilities.
- `dom.js`: centralized DOM element map.
- `ui-render.js`: shared UI message/status/tacho rendering helpers.
- `flow-render.js`: step and list rendering helpers for flow screens.
- `flow-controller.js`: step transitions and flow-mode guards.

`public/app.js` is still the main bootstrap and workflow orchestrator, but rendering and helper logic are being progressively extracted to keep behavior stable while reducing coupling.

## GoDaddy Upload Notes

- Upload the full project (including `public/`) so module imports like `public/js/utils.js` are available.
- If deploying under a subfolder (for example `/installer/`), keep frontend requests relative to the app root. The current `api.js` + `utils.js` setup already resolves this.
- Node.js hosting is required for this project because `server.js` handles sessions and CRM API proxying. Shared static hosting alone is not sufficient.
