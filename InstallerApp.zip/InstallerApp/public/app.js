import { apiRequest } from "./js/api.js";
import { getElements } from "./js/dom.js";
import {
  applyStep,
  deriveDefaultFlowMode,
  isCheckExistingMode as isCheckExistingModeFlow,
  isValidFlowMode
} from "./js/flow-controller.js";
import {
  renderAdminDevices as renderAdminDevicesView,
  renderCustomers as renderCustomersView,
  renderModeChoice as renderModeChoiceView,
  renderRoleSections as renderRoleSectionsView,
  renderSelectedDevice as renderSelectedDeviceView,
  renderStatusLayout as renderStatusLayoutView,
  renderStep3Layout as renderStep3LayoutView,
  renderSummary as renderSummaryView
} from "./js/flow-render.js";
import {
  KNOWN_INSTALL_FIELDS,
  REMOVED_INSTALL_FIELDS,
  getMissingRequiredInstallFields,
  toFieldLabel
} from "./js/install-form.js";
import {
  clearFieldValidationFromEvent,
  clearInstallFieldValidationState,
  getInstallFieldInput,
  markFieldValidationError
} from "./js/install-validation.js";
import {
  clearMessage as uiClearMessage,
  resetTachoPanel as uiResetTachoPanel,
  setFuelSourceFlags as uiSetFuelSourceFlags,
  setMessage as uiSetMessage,
  setStatusDetailState as uiSetStatusDetailState,
  setTachoPanelState as uiSetTachoPanelState,
  setVoltageContext as uiSetVoltageContext
} from "./js/ui-render.js";
import {
  getAccountTypes,
  getRoleList,
  isAdminUser,
  toRoleLabel
} from "./js/roles.js";
import {
  CAMERA_CHECKLIST_TEMPLATE,
  FLOW_MODES,
  TACHO_PANEL_STATES,
  createInitialCameraChecklist,
  createInitialInstallForm,
  createInitialInstallOptions,
  createInitialState,
  toInstallOptions
} from "./js/state.js";

const state = createInitialState();
const elements = getElements();

function setMessage(text, type = "info") {
  uiSetMessage(elements, text, type);
}

function clearMessage() {
  uiClearMessage(elements);
}

async function withButtonBusy(button, busyLabel, task) {
  if (!button) {
    return task();
  }

  const previousText = button.textContent;
  const wasDisabled = button.disabled;

  button.disabled = true;
  button.textContent = busyLabel;
  button.setAttribute("aria-busy", "true");

  try {
    return await task();
  } finally {
    button.disabled = wasDisabled;
    button.textContent = previousText;
    button.removeAttribute("aria-busy");
  }
}

function isCheckExistingMode() {
  return isCheckExistingModeFlow(state.flowMode, FLOW_MODES);
}

function setDefaultFlowModeForUser() {
  state.flowMode = deriveDefaultFlowMode(state.user, FLOW_MODES, isAdminUser);
}

function renderModeChoice() {
  renderModeChoiceView(elements, {
    isAdmin: isAdminUser(state.user),
    flowMode: state.flowMode,
    flowModes: FLOW_MODES
  });
}

function renderStep3Layout() {
  renderStep3LayoutView(elements, {
    checkExisting: isCheckExistingMode()
  });
}

function renderStatusLayout() {
  renderStatusLayoutView(elements, {
    checkExisting: isCheckExistingMode()
  });
}

function setFlowMode(mode) {
  if (!isValidFlowMode(mode, FLOW_MODES)) {
    return;
  }

  clearInstallFieldValidationState(elements);

  state.flowMode = mode;
  state.selectedDevice = null;
  state.status = null;
  state.tacho = null;
  state.adminDevices = [];
  resetCameraChecklist();

  elements.adminDeviceSearchInput.value = "";
  elements.adminDeviceList.innerHTML = "";
  resetTachoPanel();

  renderModeChoice();
  renderRoleSections();
  renderStep3Layout();
  renderStatusLayout();
  renderSelectedDevice();
  renderCustomers();
}

function setRoleUI() {
  const isAuthenticated = Boolean(state.user);
  elements.logoutButton.classList.toggle("hidden", !isAuthenticated);
  elements.userRoleChip.classList.toggle("hidden", !isAuthenticated);

  if (isAuthenticated) {
    const accountTypes = getAccountTypes(state.user);
    const primaryAccountType = accountTypes[0] || "user";
    const roles = getRoleList(state.user);

    const accountTypeLabel = toRoleLabel(primaryAccountType);
    const roleLabels = roles.map((role) => toRoleLabel(role)).filter(Boolean);
    const rolePart = roleLabels.join(", ");

    elements.userRoleChip.textContent = rolePart
      ? `${accountTypeLabel} · ${rolePart}`
      : accountTypeLabel;
    elements.userRoleChip.title = rolePart
      ? `Account type: ${accountTypeLabel}. Roles: ${rolePart}`
      : `Account type: ${accountTypeLabel}.`;
    return;
  }

  elements.userRoleChip.textContent = "";
  elements.userRoleChip.removeAttribute("title");
}

function isDeviceInstalledStatus(status) {
  const normalized = String(status || "").toLowerCase();
  return normalized === "installed" || normalized === "client";
}

function extractStatusScalar(value) {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === "object") {
    const nestedKeys = ["value", "status", "state", "connected"];
    for (const key of nestedKeys) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        return extractStatusScalar(value[key]);
      }
    }

    return null;
  }

  return value;
}

function normalizeStatusFlag(value) {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value === "number") {
    return value > 0;
  }

  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (!normalized) {
      return false;
    }

    if (
      ["true", "1", "yes", "on", "ok", "active", "connected", "receiving"].includes(
        normalized
      )
    ) {
      return true;
    }

    if (
      ["false", "0", "no", "off", "inactive", "disconnected", "n/a", "na"].includes(
        normalized
      )
    ) {
      return false;
    }

    const numeric = Number(normalized);
    if (Number.isFinite(numeric)) {
      return numeric > 0;
    }
  }

  return false;
}

function formatFuelSignalFlag(value) {
  const scalar = extractStatusScalar(value);
  if (scalar === null) {
    return "Not reported";
  }

  return normalizeStatusFlag(scalar) ? "Active" : "Inactive";
}

function hasReportedStatusValue(value) {
  const scalar = extractStatusScalar(value);
  if (scalar === null) {
    return false;
  }

  if (typeof scalar === "string") {
    return scalar.trim().length > 0;
  }

  return true;
}

function formatVoltageValue(value) {
  const scalar = extractStatusScalar(value);
  if (scalar === null) {
    return "Not reported";
  }

  if (typeof scalar === "number" && Number.isFinite(scalar)) {
    return `${scalar} V`;
  }

  if (typeof scalar === "string") {
    const trimmed = scalar.trim();
    if (!trimmed) {
      return "Not reported";
    }

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) {
      return `${numeric} V`;
    }

    return trimmed;
  }

  if (typeof scalar === "boolean") {
    return scalar ? "Yes" : "No";
  }

  return "Not reported";
}

function setFuelSourceFlags({ can = "-", canTotal = "-" } = {}) {
  uiSetFuelSourceFlags(elements, { can, canTotal });
}

function setVoltageContext({ summary = "-", supply = "-" } = {}) {
  uiSetVoltageContext(elements, { summary, supply });
}

function setStatusDetailState(label) {
  uiSetStatusDetailState(elements, label);
}

function setTachoPanelState({
  panelState = TACHO_PANEL_STATES.PENDING,
  message = "No tacho test has been run.",
  vehicleRegistration = "-",
  totalDistance = "-"
} = {}) {
  uiSetTachoPanelState(elements, TACHO_PANEL_STATES, {
    panelState,
    message,
    vehicleRegistration,
    totalDistance
  });
}

function resetTachoPanel() {
  uiResetTachoPanel(elements, TACHO_PANEL_STATES);
}

function getTachoInputValue(inputs, candidateKeys = []) {
  if (!inputs || typeof inputs !== "object") {
    return null;
  }

  const keyLookup = new Map(
    Object.keys(inputs).map((key) => [String(key).toLowerCase(), key])
  );

  for (const candidateKey of candidateKeys) {
    const resolvedKey = keyLookup.get(String(candidateKey).toLowerCase());
    if (!resolvedKey) {
      continue;
    }

    const value = extractStatusScalar(inputs[resolvedKey]);
    if (value === null || value === undefined) {
      continue;
    }

    if (typeof value === "string" && value.trim() === "") {
      continue;
    }

    return value;
  }

  return null;
}

function formatTachoFieldValue(value) {
  if (value === null || value === undefined) {
    return "Not reported";
  }

  if (typeof value === "string") {
    const trimmed = value.trim();
    return trimmed || "Not reported";
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return String(value);
  }

  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  return "Not reported";
}

function toFiniteNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  const directNumeric = Number(trimmed);
  if (Number.isFinite(directNumeric)) {
    return directNumeric;
  }

  const normalizedDecimal = trimmed.replace(",", ".");
  const parsedNumeric = Number.parseFloat(normalizedDecimal);
  if (Number.isFinite(parsedNumeric)) {
    return parsedNumeric;
  }

  return null;
}

function formatTachoDistanceKilometers(value) {
  const rawDistanceValue = toFiniteNumber(value);
  if (rawDistanceValue === null) {
    return "Not reported";
  }

  const kilometers = rawDistanceValue * 0.005;
  const roundedKilometers = Number(kilometers.toFixed(2));
  return `${roundedKilometers} km`;
}

function isCameraCapableDevice(device = state.selectedDevice) {
  if (!device || typeof device !== "object") {
    return false;
  }

  const capability = device.cameraCapability;
  if (!capability || typeof capability !== "object") {
    return false;
  }

  return Boolean(capability.isCamera || capability.isCameraUnit);
}

function syncCameraChecklistFromInputs() {
  state.cameraChecklist = {
    mountingVerified: Boolean(elements.cameraCheckMounting?.checked),
    visibilityVerified: Boolean(elements.cameraCheckVisibility?.checked),
    powerVerified: Boolean(elements.cameraCheckPower?.checked),
    orientationVerified: Boolean(elements.cameraCheckOrientation?.checked)
  };
}

function renderCameraChecklistInputs() {
  elements.cameraCheckMounting.checked = Boolean(state.cameraChecklist.mountingVerified);
  elements.cameraCheckVisibility.checked = Boolean(state.cameraChecklist.visibilityVerified);
  elements.cameraCheckPower.checked = Boolean(state.cameraChecklist.powerVerified);
  elements.cameraCheckOrientation.checked = Boolean(state.cameraChecklist.orientationVerified);
}

function setCameraChecklistDisabled(disabled) {
  elements.cameraCheckMounting.disabled = disabled;
  elements.cameraCheckVisibility.disabled = disabled;
  elements.cameraCheckPower.disabled = disabled;
  elements.cameraCheckOrientation.disabled = disabled;
}

function resetCameraChecklist() {
  state.cameraChecklist = createInitialCameraChecklist();
  renderCameraChecklistInputs();
}

function isCameraChecklistComplete() {
  return Object.values(state.cameraChecklist).every(Boolean);
}

function renderCameraChecklist() {
  if (isCheckExistingMode()) {
    elements.cameraQualityPanel.classList.add("hidden");
    elements.step4NextButton.disabled = false;
    return;
  }

  const isCameraDevice = isCameraCapableDevice();
  elements.cameraQualityPanel.classList.toggle("hidden", !isCameraDevice);

  if (!isCameraDevice) {
    elements.step4NextButton.disabled = false;
    return;
  }

  const capability = state.selectedDevice?.cameraCapability || {};
  const reasons = Array.isArray(capability.reasons) ? capability.reasons : [];
  const reasonText = reasons.length > 0 ? `Signals: ${reasons.slice(0, 3).join(", ")}.` : "";
  const confidence = capability.confidence || "low";
  elements.cameraCapabilityMeta.textContent =
    `Camera-capable unit detected (confidence: ${confidence}). ${reasonText}`.trim();

  const completedChecks = Object.values(state.cameraChecklist).filter(Boolean).length;
  const totalChecks = Object.keys(CAMERA_CHECKLIST_TEMPLATE).length;
  const checksComplete = completedChecks === totalChecks;
  elements.cameraCheckProgress.textContent = checksComplete
    ? "Camera quality checks complete."
    : `${completedChecks}/${totalChecks} camera quality checks complete.`;

  const lockedByInstallStatus = state.status?.installed === false;
  setCameraChecklistDisabled(lockedByInstallStatus);
  elements.step4NextButton.disabled = lockedByInstallStatus || !checksComplete;
}

function handleCameraChecklistChanged() {
  syncCameraChecklistFromInputs();
  renderCameraChecklist();
}

function setStep(step) {
  applyStep(state, elements, step, {
    onEnterStep3: () => {
      renderRoleSections();
      renderStep3Layout();
      renderSelectedDevice();
    },
    onEnterStep4: () => {
      renderSummary();
    },
    onEnterStep5: () => {
      renderStatusLayout();
      renderCameraChecklist();
      runStatusCheck();
    }
  });
}

function resetInstallForm() {
  state.installForm = createInitialInstallForm();

  elements.vehicleLicenseInput.value = "";
  elements.vehicleVinInput.value = "";
  elements.vehicleTypeInput.value = "";
  elements.vehicleNotesInput.value = "";

  elements.installRequiredList.innerHTML = "";
  elements.installRequiredPanel.classList.add("hidden");
  elements.dynamicInstallFields.innerHTML = "";
}

function renderVehicleTypeOptions() {
  const previousValue = elements.vehicleTypeInput.value;
  elements.vehicleTypeInput.innerHTML =
    '<option value="">Select vehicle type</option>';

  for (const vehicleType of state.installOptions.vehicleTypes) {
    const option = document.createElement("option");
    option.value = vehicleType.id;
    option.textContent = vehicleType.title;
    elements.vehicleTypeInput.appendChild(option);
  }

  if (
    previousValue &&
    state.installOptions.vehicleTypes.some((item) => item.id === previousValue)
  ) {
    elements.vehicleTypeInput.value = previousValue;
  }
}

function renderDynamicRequiredFields(requiredFields) {
  elements.dynamicInstallFields.innerHTML = "";

  const dynamicFields = requiredFields.filter(
    (fieldName) =>
      !KNOWN_INSTALL_FIELDS.has(fieldName) &&
      !REMOVED_INSTALL_FIELDS.has(fieldName)
  );

  for (const fieldName of dynamicFields) {
    const label = document.createElement("label");
    label.textContent = toFieldLabel(fieldName);

    const input = document.createElement("input");
    input.type = /id|year|month|hours|speed|odometer/i.test(fieldName)
      ? "number"
      : "text";
    input.dataset.fieldName = fieldName;
    input.required = true;
    input.placeholder = `Enter ${toFieldLabel(fieldName).toLowerCase()}`;

    const previousValue = state.installForm.extraFields[fieldName];
    if (previousValue) {
      input.value = previousValue;
    }

    label.appendChild(input);
    elements.dynamicInstallFields.appendChild(label);
  }
}

function renderInstallRequirements() {
  const requiredFields = Array.isArray(state.installOptions.requiredFieldsInstall)
    ? state.installOptions.requiredFieldsInstall.filter(
        (fieldName) => !REMOVED_INSTALL_FIELDS.has(fieldName)
      )
    : [];

  const requiredSet = new Set(requiredFields);
  elements.vehicleLicenseInput.required = true;
  elements.vehicleVinInput.required = requiredSet.has("vinNumber");
  elements.vehicleTypeInput.required = requiredSet.has("vehicleType");
  elements.vehicleNotesInput.required = requiredSet.has("notes");

  renderVehicleTypeOptions();
  renderDynamicRequiredFields(requiredFields);

  elements.installRequiredList.innerHTML = "";

  if (requiredFields.length === 0) {
    elements.installRequiredPanel.classList.add("hidden");
    return;
  }

  for (const fieldName of requiredFields) {
    const item = document.createElement("li");
    item.textContent = toFieldLabel(fieldName);
    elements.installRequiredList.appendChild(item);
  }

  elements.installRequiredPanel.classList.remove("hidden");
}

async function loadInstallOptions() {
  try {
    const response = await apiRequest("/api/install/options");
    state.installOptions = toInstallOptions(response.data);
  } catch {
    state.installOptions = createInitialInstallOptions();
  }

  renderInstallRequirements();
}

function collectInstallForm() {
  const extraFields = {};
  const dynamicInputs = elements.dynamicInstallFields.querySelectorAll("input[data-field-name]");

  for (const input of dynamicInputs) {
    const fieldName = input.dataset.fieldName;
    const value = input.value.trim();
    if (fieldName && value) {
      extraFields[fieldName] = value;
    }
  }

  state.installForm = {
    licensePlate: elements.vehicleLicenseInput.value.trim(),
    vinNumber: elements.vehicleVinInput.value.trim(),
    vehicleType: elements.vehicleTypeInput.value.trim(),
    notes: elements.vehicleNotesInput.value.trim(),
    extraFields
  };
}

async function restoreSession() {
  try {
    const session = await apiRequest("/api/session");
    if (!session.authenticated) {
      setStep(1);
      return;
    }

    if (session.user) {
      state.user = session.user;
    } else {
      const account = await apiRequest("/api/account");
      state.user = account.user;
    }

    setDefaultFlowModeForUser();
    setRoleUI();
    renderModeChoice();
    renderStep3Layout();
    renderStatusLayout();
    await loadCustomers();
    setStep(2);
  } catch {
    setStep(1);
  }
}

function showTwoFa(enabled) {
  elements.twoFaWrap.classList.toggle("hidden", !enabled);
  if (!enabled) {
    elements.twoFaInput.value = "";
  }
}

async function handleLogin(event) {
  event.preventDefault();
  clearMessage();

  const username = elements.usernameInput.value.trim();
  const password = elements.passwordInput.value;
  const twoFactorCode = elements.twoFaInput.value.trim();

  if (!username || !password) {
    setMessage("Enter username and password.", "error");
    return;
  }

  await withButtonBusy(elements.loginButton, "Signing In...", async () => {
    try {
      const response = await apiRequest("/api/auth/login", {
        method: "POST",
        body: {
          username,
          password,
          twoFactorCode: twoFactorCode || undefined
        }
      });

      if (response.requiresTwoFactor) {
        showTwoFa(true);
        setMessage(response.message || "Two-factor code required.", "info");
        return;
      }

      state.user = response.user;
      setDefaultFlowModeForUser();
      elements.passwordInput.value = "";
      elements.twoFaInput.value = "";
      showTwoFa(false);
      setRoleUI();
      renderModeChoice();
      renderStep3Layout();
      renderStatusLayout();

      await loadCustomers();
      setStep(2);
      setMessage("Login successful.", "success");
    } catch (error) {
      setMessage(error.message, "error");
    }
  });
}

async function resendTwoFaCode() {
  const username = elements.usernameInput.value.trim();
  const password = elements.passwordInput.value;

  if (!username || !password) {
    setMessage("Enter username and password first.", "error");
    return;
  }

  try {
    await withButtonBusy(elements.resendTwoFaButton, "Sending...", async () => {
      await apiRequest("/api/auth/send-2fa", {
        method: "POST",
        body: { username, password }
      });
    });
    setMessage("2FA code sent.", "info");
  } catch (error) {
    setMessage(error.message, "error");
  }
}

async function handleLogout() {
  try {
    await withButtonBusy(elements.logoutButton, "Logging Out...", async () => {
      await apiRequest("/api/auth/logout", { method: "POST" });
    });
  } catch {
    // ignore logout errors and reset client state regardless
  }

  state.user = null;
  state.flowMode = null;
  state.customer = null;
  state.customers = [];
  state.installOptions = createInitialInstallOptions();
  state.adminDevices = [];
  state.selectedDevice = null;
  state.status = null;
  state.tacho = null;
  resetInstallForm();
  clearInstallFieldValidationState(elements);
  resetCameraChecklist();

  elements.customerList.innerHTML = "";
  elements.adminDeviceList.innerHTML = "";
  elements.techImeiInput.value = "";
  elements.techFindMessage.textContent = "";
  elements.usernameInput.value = "";
  elements.passwordInput.value = "";
  showTwoFa(false);
  setRoleUI();
  renderModeChoice();
  renderStep3Layout();
  renderStatusLayout();
  resetTachoPanel();
  clearMessage();
  renderCameraChecklist();
  setStep(1);
}

async function loadCustomers() {
  const response = await apiRequest("/api/customers");
  state.customers = response.data || [];
  state.customer = null;
  renderCustomers();
}

function renderCustomers() {
  renderCustomersView(elements, {
    customers: state.customers,
    selectedCustomerId: state.customer?.id || null,
    isAdmin: isAdminUser(state.user),
    flowMode: state.flowMode,
    flowModes: FLOW_MODES,
    onSelectCustomer: (customer) => {
      state.customer = customer;
      renderCustomers();
      clearMessage();
    }
  });
}

function renderRoleSections() {
  renderRoleSectionsView(elements, {
    isAdmin: isAdminUser(state.user),
    checkExisting: isCheckExistingMode()
  });
}

async function moveToStep3() {
  if (isAdminUser(state.user) && !state.flowMode) {
    setMessage("Choose New Install or Check Existing Device first.", "error");
    return;
  }

  if (!state.customer) {
    setMessage("Select a customer to continue.", "error");
    return;
  }

  try {
    await withButtonBusy(elements.customerNextButton, "Loading...", async () => {
      clearMessage();
      state.selectedDevice = null;
      state.status = null;
      state.tacho = null;
      resetInstallForm();
      resetCameraChecklist();
      elements.techImeiInput.value = "";
      elements.techFindMessage.textContent = "";
      resetTachoPanel();
      elements.adminDeviceSearchInput.value = "";

      if (!isCheckExistingMode()) {
        await loadInstallOptions();
      } else {
        elements.installRequiredPanel.classList.add("hidden");
        elements.dynamicInstallFields.innerHTML = "";
      }

      if (isAdminUser(state.user)) {
        await loadAdminDevices();
      }

      renderStep3Layout();
      renderStatusLayout();
      renderCameraChecklist();
      setStep(3);
    });
  } catch (error) {
    setMessage(error?.message || "Unable to load customer devices.", "error");
  }
}

async function loadAdminDevices() {
  const checkExisting = isCheckExistingMode();
  setMessage(
    checkExisting ? "Loading installed devices..." : "Loading warehouse devices...",
    "info"
  );

  const endpoint = checkExisting
    ? `/api/devices/company/${state.customer.id}/installed`
    : `/api/devices/company/${state.customer.id}`;

  const response = await apiRequest(endpoint);
  state.adminDevices = response.data || [];
  renderAdminDevices();
  clearMessage();
}

function renderAdminDevices() {
  renderAdminDevicesView(elements, {
    adminDevices: state.adminDevices,
    selectedDeviceId: state.selectedDevice?.id || null,
    checkExisting: isCheckExistingMode(),
    onSelectDevice: (device) => {
      state.selectedDevice = device;
      state.status = null;
      state.tacho = null;
      resetCameraChecklist();
      resetTachoPanel();
      renderAdminDevices();
      renderSelectedDevice();
      renderCameraChecklist();
      clearMessage();
    }
  });
}

async function findTechnicianDevice() {
  const searchValue = elements.techImeiInput.value.trim();
  if (!searchValue) {
    setMessage("Enter an IMEI or serial number to search.", "error");
    return;
  }

  elements.techFindMessage.textContent =
    "Searching warehouse for this IMEI or serial...";

  try {
    await withButtonBusy(elements.techFindButton, "Searching...", async () => {
      elements.techImeiInput.disabled = true;

      try {
        const response = await apiRequest(
          `/api/devices/company/${state.customer.id}/find-by-imei?query=${encodeURIComponent(searchValue)}`
        );

        state.selectedDevice = response.data;
        state.status = null;
        state.tacho = null;
        resetCameraChecklist();
        resetTachoPanel();
        renderSelectedDevice();
        renderCameraChecklist();
        elements.techFindMessage.textContent = "Device found and selected.";
        clearMessage();
      } finally {
        elements.techImeiInput.disabled = false;
      }
    });
  } catch (error) {
    elements.techFindMessage.textContent = "";
    setMessage(error.message, "error");
  }
}

function renderSelectedDevice() {
  renderSelectedDeviceView(elements, state.selectedDevice);
}

async function moveFromStep3ToStep4() {
  collectInstallForm();
  clearInstallFieldValidationState(elements);

  if (!state.selectedDevice) {
    setMessage("Select a device before continuing.", "error");
    return;
  }

  if (isCheckExistingMode()) {
    clearMessage();
    setStep(5);
    return;
  }

  if (state.installForm.licensePlate.length < 2) {
    markFieldValidationError(
      elements.vehicleLicenseInput,
      "Enter a valid licence plate (at least 2 characters)."
    );
    setMessage("Enter a valid licence plate.", "error");
    return;
  }

  if (state.installForm.vinNumber && state.installForm.vinNumber.length < 6) {
    markFieldValidationError(
      elements.vehicleVinInput,
      "VIN must be at least 6 characters when provided."
    );
    setMessage("VIN must be at least 6 characters when provided.", "error");
    return;
  }

  const missingRequiredFields = getMissingRequiredInstallFields(
    state.installOptions.requiredFieldsInstall,
    state.installForm
  );
  if (missingRequiredFields.length > 0) {
    const firstMissingField = missingRequiredFields[0];
    const firstMissingInput = getInstallFieldInput(elements, firstMissingField);
    if (firstMissingInput) {
      markFieldValidationError(
        firstMissingInput,
        `Complete ${toFieldLabel(firstMissingField)}.`
      );
    }

    const labels = missingRequiredFields.map((fieldName) => toFieldLabel(fieldName));
    setMessage(`Complete required fields: ${labels.join(", ")}.`, "error");
    return;
  }

  clearMessage();
  setStep(4);
}

async function runStatusCheck() {
  if (!state.selectedDevice?.id) {
    elements.statusGps.textContent = "Pending";
    elements.statusFuel.textContent = "Pending";
    setStatusDetailState("Pending");
    elements.statusLastUpdated.textContent = "-";
    resetTachoPanel();
    renderCameraChecklist();
    return;
  }
  renderCameraChecklist();

  if (
    state.selectedDevice.status &&
    !isDeviceInstalledStatus(state.selectedDevice.status)
  ) {
    state.status = {
      installed: false,
      gps: false,
      fuel: false,
      tachoAvailable: false,
      lastDataReceived: null
    };

    elements.statusGps.textContent = "Not Installed";
    elements.statusFuel.textContent = "Not Installed";
    setStatusDetailState("Not Installed");
    elements.statusLastUpdated.textContent = "-";
    elements.runTachoButton.disabled = true;
    setTachoPanelState({
      panelState: TACHO_PANEL_STATES.UNAVAILABLE,
      message: "Device is still in warehouse. Install it first, then run status/tacho tests.",
      vehicleRegistration: "-",
      totalDistance: "-"
    });
    setMessage("Device is not installed yet. Complete install first.", "info");
    renderCameraChecklist();
    return;
  }

  elements.statusGps.textContent = "Checking...";
  elements.statusFuel.textContent = "Checking...";
  setStatusDetailState("Checking...");
  elements.statusLastUpdated.textContent = "-";

  try {
    await withButtonBusy(elements.refreshStatusButton, "Checking...", async () => {
      const response = await apiRequest(`/api/device-status/${state.selectedDevice.id}`);
      state.status = response.data;

      if (state.status.installed === false) {
        elements.statusGps.textContent = "Not Installed";
        elements.statusFuel.textContent = "Not Installed";
        setStatusDetailState("Not Installed");
        elements.statusLastUpdated.textContent = "-";
        elements.runTachoButton.disabled = true;
        setTachoPanelState({
          panelState: TACHO_PANEL_STATES.UNAVAILABLE,
          message: "Device is still in warehouse. Install it first, then run status/tacho tests.",
          vehicleRegistration: "-",
          totalDistance: "-"
        });
        setMessage("Device is not installed yet. Complete install first.", "info");
        renderCameraChecklist();
        return;
      }

      const hasRecentData = Boolean(state.status.recentDataWithinTolerance);

      elements.statusGps.textContent =
        state.status.gps || hasRecentData ? "Receiving" : "No Signal";
      elements.statusFuel.textContent = state.status.fuel ? "Receiving" : "No Data";

      const rawStatus = state.status?.raw || {};
      setFuelSourceFlags({
        can: formatFuelSignalFlag(rawStatus?.can?.can_fuel),
        canTotal: formatFuelSignalFlag(rawStatus?.can?.can_total_fuel)
      });

      const supplyVoltageRaw = rawStatus?.other?.supply_voltage;
      const voltageSummary = hasReportedStatusValue(supplyVoltageRaw) ? "Available" : "No Data";
      setVoltageContext({
        summary: voltageSummary,
        supply: formatVoltageValue(supplyVoltageRaw)
      });

      elements.statusLastUpdated.textContent =
        state.status.lastDataReceived?.localized ||
        state.status.lastDataReceived?.raw ||
        "Unknown";

      elements.runTachoButton.disabled = !state.status.tachoAvailable;
      if (!state.status.tachoAvailable) {
        setTachoPanelState({
          panelState: TACHO_PANEL_STATES.UNAVAILABLE,
          message: "Tacho test not available for this device.",
          vehicleRegistration: "-",
          totalDistance: "-"
        });
      } else if (!state.tacho) {
        resetTachoPanel();
      }
      renderCameraChecklist();
    });
  } catch (error) {
    setMessage(error.message, "error");
    setStatusDetailState("Unavailable");
    setTachoPanelState({
      panelState: TACHO_PANEL_STATES.UNAVAILABLE,
      message: "Tacho status unavailable.",
      vehicleRegistration: "-",
      totalDistance: "-"
    });
    elements.runTachoButton.disabled = true;
    renderCameraChecklist();
  }
}

async function runTachoTest() {
  if (!state.selectedDevice?.id) {
    setMessage("Select a device first.", "error");
    return;
  }

  if (
    (state.selectedDevice.status &&
      !isDeviceInstalledStatus(state.selectedDevice.status)) ||
    state.status?.installed === false
  ) {
    setTachoPanelState({
      panelState: TACHO_PANEL_STATES.UNAVAILABLE,
      message: "Device is still in warehouse. Install it first, then run tacho test.",
      vehicleRegistration: "-",
      totalDistance: "-"
    });
    setMessage("Tacho test requires an installed device.", "info");
    return;
  }

  setTachoPanelState({
    panelState: TACHO_PANEL_STATES.RUNNING,
    message: "Running tacho test...",
    vehicleRegistration: "-",
    totalDistance: "-"
  });

  try {
    await withButtonBusy(elements.runTachoButton, "Running...", async () => {
      const response = await apiRequest(`/api/device-tacho/${state.selectedDevice.id}`);
      state.tacho = response.data;

      if (state.tacho.installed === false) {
        setTachoPanelState({
          panelState: TACHO_PANEL_STATES.UNAVAILABLE,
          message: "Device is still in warehouse. Install it first, then run tacho test.",
          vehicleRegistration: "-",
          totalDistance: "-"
        });
        setMessage("Tacho test requires an installed device.", "info");
        return;
      }

      const tachoInputs = state.tacho.inputs || {};
      const vehicleRegistration = formatTachoFieldValue(
        getTachoInputValue(tachoInputs, [
          "TACHO_CAN_VEHICLE_REGISTRATION_NUMBER",
          "tacho_can_vehicle_registration_number",
          "vehicle_registration_number"
        ])
      );
      const totalDistance = formatTachoDistanceKilometers(
        getTachoInputValue(tachoInputs, [
          "TACHO_CAN_TOTAL_DISTANCE",
          "tacho_can_total_distance",
          "can_total_distance"
        ])
      );

      setTachoPanelState({
        panelState: state.tacho.success ? TACHO_PANEL_STATES.PASS : TACHO_PANEL_STATES.FAIL,
        message: state.tacho.success
          ? "Tacho connection successful."
          : "Tacho connection test returned a failure state.",
        vehicleRegistration: state.tacho.success ? vehicleRegistration : "-",
        totalDistance: state.tacho.success ? totalDistance : "-"
      });

      setMessage(
        state.tacho.success ? "Tacho test passed." : "Tacho test returned a failure state.",
        state.tacho.success ? "success" : "info"
      );
    });
  } catch (error) {
    setTachoPanelState({
      panelState: TACHO_PANEL_STATES.FAIL,
      message: "Tacho test failed.",
      vehicleRegistration: "-",
      totalDistance: "-"
    });
    setMessage(error.message, "error");
  }
}

function renderSummary() {
  renderSummaryView(elements, {
    customer: state.customer,
    selectedDevice: state.selectedDevice,
    installForm: state.installForm
  });
}

async function completeInstall() {
  if (isCheckExistingMode()) {
    setMessage("Install completion is not available in check-existing mode.", "error");
    return;
  }

  if (!state.customer || !state.selectedDevice) {
    setMessage("Customer and device selection are required.", "error");
    return;
  }

  collectInstallForm();

  try {
    await withButtonBusy(elements.completeInstallButton, "Completing...", async () => {
      await apiRequest("/api/installations/complete", {
        method: "POST",
        body: {
          companyId: state.customer.id,
          deviceId: state.selectedDevice.id,
          licensePlate: state.installForm.licensePlate,
          vinNumber: state.installForm.vinNumber,
          vehicleType: state.installForm.vehicleType,
          notes: state.installForm.notes,
          additionalFields: state.installForm.extraFields
        }
      });
    });

    setMessage("Installation completed. Running post-install status check.", "success");

    if (state.selectedDevice) {
      state.selectedDevice.status = "installed";
    }

    state.status = null;
    state.tacho = null;
    resetTachoPanel();
    setStep(5);
  } catch (error) {
    setMessage(error.message, "error");
  }
}

async function startNextInstall() {
  if (isCheckExistingMode()) {
    try {
      await withButtonBusy(elements.step4NextButton, "Loading...", async () => {
        clearMessage();
        state.selectedDevice = null;
        state.status = null;
        state.tacho = null;
        resetCameraChecklist();
        resetTachoPanel();

        if (isAdminUser(state.user)) {
          await loadAdminDevices();
        }

        renderSelectedDevice();
        renderCameraChecklist();
        setStep(3);
      });
    } catch (error) {
      setMessage(error?.message || "Unable to load devices.", "error");
    }
    return;
  }

  if (isCameraCapableDevice() && !isCameraChecklistComplete()) {
    setMessage(
      "Complete all camera quality checks before starting the next install.",
      "error"
    );
    return;
  }

  try {
    await withButtonBusy(elements.step4NextButton, "Loading...", async () => {
      clearMessage();
      state.selectedDevice = null;
      state.status = null;
      state.tacho = null;
      resetInstallForm();
      clearInstallFieldValidationState(elements);
      resetCameraChecklist();
      renderInstallRequirements();
      elements.techImeiInput.value = "";
      elements.techFindMessage.textContent = "";
      resetTachoPanel();

      if (isAdminUser(state.user)) {
        await loadAdminDevices();
      }

      renderSelectedDevice();
      renderCameraChecklist();
      setStep(3);
    });
  } catch (error) {
    setMessage(error?.message || "Unable to load devices.", "error");
  }
}

function wireEvents() {
  elements.loginForm.addEventListener("submit", handleLogin);
  elements.resendTwoFaButton.addEventListener("click", resendTwoFaCode);
  elements.logoutButton.addEventListener("click", handleLogout);

  const installFields = [
    elements.vehicleLicenseInput,
    elements.vehicleVinInput,
    elements.vehicleTypeInput,
    elements.vehicleNotesInput
  ];
  for (const field of installFields) {
    field.addEventListener("input", clearFieldValidationFromEvent);
    field.addEventListener("change", clearFieldValidationFromEvent);
  }
  elements.dynamicInstallFields.addEventListener("input", clearFieldValidationFromEvent);
  elements.dynamicInstallFields.addEventListener("change", clearFieldValidationFromEvent);

  elements.modeNewInstallButton.addEventListener("click", () => {
    setFlowMode(FLOW_MODES.NEW_INSTALL);
    clearMessage();
  });

  elements.modeCheckExistingButton.addEventListener("click", () => {
    setFlowMode(FLOW_MODES.CHECK_EXISTING);
    clearMessage();
  });

  elements.customerSearchInput.addEventListener("input", renderCustomers);
  elements.customerNextButton.addEventListener("click", moveToStep3);

  elements.adminDeviceSearchInput.addEventListener("input", renderAdminDevices);
  elements.techFindButton.addEventListener("click", findTechnicianDevice);

  elements.step3BackButton.addEventListener("click", () => setStep(2));
  elements.step3NextButton.addEventListener("click", moveFromStep3ToStep4);

  elements.refreshStatusButton.addEventListener("click", runStatusCheck);
  elements.runTachoButton.addEventListener("click", runTachoTest);
  elements.cameraCheckMounting.addEventListener("change", handleCameraChecklistChanged);
  elements.cameraCheckVisibility.addEventListener("change", handleCameraChecklistChanged);
  elements.cameraCheckPower.addEventListener("change", handleCameraChecklistChanged);
  elements.cameraCheckOrientation.addEventListener("change", handleCameraChecklistChanged);

  elements.step4BackButton.addEventListener("click", () => setStep(3));
  elements.step4NextButton.addEventListener("click", startNextInstall);

  elements.step5BackButton.addEventListener("click", () => setStep(3));
  elements.completeInstallButton.addEventListener("click", completeInstall);
}

function init() {
  wireEvents();
  setRoleUI();
  renderModeChoice();
  renderStep3Layout();
  renderStatusLayout();
  showTwoFa(false);
  resetCameraChecklist();
  renderCameraChecklist();
  restoreSession();
}

init();
