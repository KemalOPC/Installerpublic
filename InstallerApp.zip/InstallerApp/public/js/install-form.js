export const INSTALL_FIELD_LABELS = {
  carNumber: "Licence Plate",
  vinNumber: "VIN Number",
  vehicleType: "Vehicle Type",
  notes: "Install Notes",
  registrationYear: "Registration Year",
  registrationMonth: "Registration Month",
  odometer: "Odometer",
  engineHours: "Engine Hours",
  maxSpeed: "Max Speed"
};

export const REMOVED_INSTALL_FIELDS = new Set([
  "carLabel",
  "carNickname",
  "presetId",
  "mappingPresetId"
]);

export const KNOWN_INSTALL_FIELDS = new Set(Object.keys(INSTALL_FIELD_LABELS));

export function toFieldLabel(fieldName) {
  if (INSTALL_FIELD_LABELS[fieldName]) {
    return INSTALL_FIELD_LABELS[fieldName];
  }

  return fieldName
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .replace(/^./, (char) => char.toUpperCase());
}

function hasRequiredValue(value) {
  if (value === undefined || value === null) {
    return false;
  }

  if (typeof value === "string") {
    return value.trim().length > 0;
  }

  return true;
}

function getInstallFieldValue(fieldName, formData) {
  const byFieldName = {
    carNumber: formData.licensePlate,
    vinNumber: formData.vinNumber,
    vehicleType: formData.vehicleType,
    notes: formData.notes
  };

  if (fieldName in byFieldName) {
    return byFieldName[fieldName];
  }

  return formData.extraFields[fieldName];
}

export function getMissingRequiredInstallFields(requiredFieldsInstall, formData) {
  const requiredFields = Array.isArray(requiredFieldsInstall)
    ? requiredFieldsInstall.filter((fieldName) => !REMOVED_INSTALL_FIELDS.has(fieldName))
    : [];

  return requiredFields.filter((fieldName) =>
    !hasRequiredValue(getInstallFieldValue(fieldName, formData))
  );
}
