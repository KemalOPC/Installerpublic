export function clearInputValidation(input) {
  if (!input || typeof input.setCustomValidity !== "function") {
    return;
  }

  input.setCustomValidity("");
  input.removeAttribute("aria-invalid");
}

export function clearInstallFieldValidationState(elements) {
  clearInputValidation(elements.vehicleLicenseInput);
  clearInputValidation(elements.vehicleVinInput);
  clearInputValidation(elements.vehicleTypeInput);
  clearInputValidation(elements.vehicleNotesInput);

  const dynamicInputs = elements.dynamicInstallFields.querySelectorAll(
    "input[data-field-name]"
  );
  for (const input of dynamicInputs) {
    clearInputValidation(input);
  }
}

export function markFieldValidationError(input, message) {
  if (!input || typeof input.setCustomValidity !== "function") {
    return false;
  }

  input.setCustomValidity(message);
  input.setAttribute("aria-invalid", "true");
  input.reportValidity();
  input.focus();
  return true;
}

export function getInstallFieldInput(elements, fieldName) {
  const byFieldName = {
    carNumber: elements.vehicleLicenseInput,
    vinNumber: elements.vehicleVinInput,
    vehicleType: elements.vehicleTypeInput,
    notes: elements.vehicleNotesInput
  };

  if (Object.prototype.hasOwnProperty.call(byFieldName, fieldName)) {
    return byFieldName[fieldName];
  }

  return elements.dynamicInstallFields.querySelector(
    `input[data-field-name="${fieldName}"]`
  );
}

export function clearFieldValidationFromEvent(event) {
  const target = event?.target;
  if (!target || typeof target.setCustomValidity !== "function") {
    return;
  }

  clearInputValidation(target);
}
