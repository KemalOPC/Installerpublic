const KNOWN_ACCOUNT_TYPES = new Set(["admin", "user", "user_all"]);

const ROLE_LABELS = {
  adjuster: "Technician",
  adjusterclient: "Client Technician",
  adjuster_client: "Client Technician",
  manager: "Manager",
  relationmanager: "Relation Manager",
  relation_manager: "Relation Manager",
  support: "Support",
  technician: "Technician",
  admin: "Admin"
};

const ROLE_ORDER = {
  technician: 1,
  adjuster: 1,
  adjusterclient: 2,
  adjuster_client: 2,
  manager: 3,
  relationmanager: 4,
  relation_manager: 4,
  support: 5,
  admin: 6
};

export function normalizeIdentityTokens(value) {
  if (value === undefined || value === null) {
    return [];
  }

  if (Array.isArray(value)) {
    return Array.from(
      new Set(value.flatMap((entry) => normalizeIdentityTokens(entry)))
    );
  }

  const raw = String(value).trim().toLowerCase();
  if (!raw) {
    return [];
  }

  const tokens = raw
    .split(/[;,|]+/)
    .map((token) => token.trim())
    .filter(Boolean);

  return Array.from(new Set(tokens.length > 0 ? tokens : [raw]));
}

export function toRoleLabel(value) {
  const normalizedValue = String(value || "").trim();
  if (!normalizedValue) {
    return "";
  }

  if (ROLE_LABELS[normalizedValue]) {
    return ROLE_LABELS[normalizedValue];
  }

  return normalizedValue
    .replace(/_/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .trim();
}

export function getAccountTypes(user) {
  const explicitTypes = normalizeIdentityTokens(user?.accountTypes).filter((token) =>
    KNOWN_ACCOUNT_TYPES.has(token)
  );

  if (explicitTypes.length > 0) {
    return explicitTypes;
  }

  return normalizeIdentityTokens(user?.type).filter((token) =>
    KNOWN_ACCOUNT_TYPES.has(token)
  );
}

export function getRoleList(user) {
  const explicitRoles = normalizeIdentityTokens(user?.roles);
  if (explicitRoles.length > 0) {
    return explicitRoles.sort((a, b) => {
      const orderA = ROLE_ORDER[a] || 99;
      const orderB = ROLE_ORDER[b] || 99;
      if (orderA !== orderB) {
        return orderA - orderB;
      }
      return a.localeCompare(b);
    });
  }

  return normalizeIdentityTokens(user?.type).filter(
    (token) => !KNOWN_ACCOUNT_TYPES.has(token)
  );
}

export function isAdminUser(user) {
  if (!user || typeof user !== "object") {
    return false;
  }

  if (user.isAdmin === true) {
    return true;
  }

  if (getAccountTypes(user).includes("admin")) {
    return true;
  }

  return String(user.role || "").trim().toLowerCase() === "admin";
}
