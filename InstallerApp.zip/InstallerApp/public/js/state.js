export const CAMERA_CHECKLIST_TEMPLATE = {
  mountingVerified: false,
  visibilityVerified: false,
  powerVerified: false,
  orientationVerified: false
};

export const FLOW_MODES = {
  NEW_INSTALL: "newInstall",
  CHECK_EXISTING: "checkExisting"
};

export const TACHO_PANEL_STATES = {
  PENDING: "pending",
  RUNNING: "running",
  PASS: "pass",
  FAIL: "fail",
  UNAVAILABLE: "unavailable"
};

export function createInitialCameraChecklist() {
  return {
    ...CAMERA_CHECKLIST_TEMPLATE
  };
}

export function createInitialInstallOptions() {
  return {
    requiredFieldsInstall: [],
    vehicleTypes: []
  };
}

export function createInitialInstallForm() {
  return {
    licensePlate: "",
    vinNumber: "",
    vehicleType: "",
    notes: "",
    extraFields: {}
  };
}

export function createInitialState() {
  return {
    step: 1,
    user: null,
    flowMode: null,
    customer: null,
    customers: [],
    installOptions: createInitialInstallOptions(),
    adminDevices: [],
    selectedDevice: null,
    status: null,
    tacho: null,
    cameraChecklist: createInitialCameraChecklist(),
    installForm: createInitialInstallForm()
  };
}

export function toInstallOptions(data) {
  return {
    requiredFieldsInstall: Array.isArray(data?.requiredFieldsInstall)
      ? data.requiredFieldsInstall
      : [],
    vehicleTypes: Array.isArray(data?.vehicleTypes) ? data.vehicleTypes : []
  };
}
