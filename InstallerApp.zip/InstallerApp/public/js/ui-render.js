export function setMessage(elements, text, type = "info") {
  elements.message.textContent = text;
  elements.message.className = `message ${type}`;
  elements.message.classList.remove("hidden");
}

export function clearMessage(elements) {
  elements.message.className = "message hidden";
  elements.message.textContent = "";
}

export function setFuelSourceFlags(elements, { can = "-", canTotal = "-" } = {}) {
  elements.statusFuelCan.textContent = can;
  elements.statusFuelCanTotal.textContent = canTotal;
}

export function setVoltageContext(elements, { summary = "-", supply = "-" } = {}) {
  elements.statusVoltageSummary.textContent = summary;
  elements.statusVoltageSupply.textContent = supply;
}

export function setStatusDetailState(elements, label) {
  setFuelSourceFlags(elements, {
    can: label,
    canTotal: label
  });
  setVoltageContext(elements, {
    summary: label,
    supply: label
  });
}

export function setTachoPanelState(elements, tachoStates, options = {}) {
  const {
    panelState = tachoStates.PENDING,
    message = "No tacho test has been run.",
    vehicleRegistration = "-",
    totalDistance = "-"
  } = options;

  const classByState = {
    [tachoStates.PENDING]: "is-pending",
    [tachoStates.RUNNING]: "is-running",
    [tachoStates.PASS]: "is-pass",
    [tachoStates.FAIL]: "is-fail",
    [tachoStates.UNAVAILABLE]: "is-unavailable"
  };

  const labelByState = {
    [tachoStates.PENDING]: "Pending",
    [tachoStates.RUNNING]: "Running",
    [tachoStates.PASS]: "Passed",
    [tachoStates.FAIL]: "Failed",
    [tachoStates.UNAVAILABLE]: "Unavailable"
  };

  elements.tachoStatusIndicator.classList.remove(
    "is-pending",
    "is-running",
    "is-pass",
    "is-fail",
    "is-unavailable"
  );
  elements.tachoStatusIndicator.classList.add(
    classByState[panelState] || classByState[tachoStates.PENDING]
  );
  elements.tachoStatusIndicator.textContent =
    labelByState[panelState] || labelByState[tachoStates.PENDING];

  elements.tachoOutput.textContent = message;
  elements.tachoVehicleRegistration.textContent = vehicleRegistration;
  elements.tachoTotalDistance.textContent = totalDistance;
}

export function resetTachoPanel(elements, tachoStates) {
  setTachoPanelState(elements, tachoStates, {
    panelState: tachoStates.PENDING,
    message: "No tacho test has been run.",
    vehicleRegistration: "-",
    totalDistance: "-"
  });
}
