export function isValidFlowMode(mode, flowModes) {
  return mode === flowModes.NEW_INSTALL || mode === flowModes.CHECK_EXISTING;
}

export function isCheckExistingMode(flowMode, flowModes) {
  return flowMode === flowModes.CHECK_EXISTING;
}

export function deriveDefaultFlowMode(user, flowModes, isAdminUser) {
  return isAdminUser(user) ? null : flowModes.NEW_INSTALL;
}

export function applyStep(state, elements, step, hooks = {}) {
  state.step = step;

  for (const page of elements.pages) {
    page.classList.toggle("active", Number(page.dataset.step) === step);
  }

  for (const item of elements.stepperItems) {
    item.classList.toggle("active", Number(item.dataset.step) <= step);
  }

  if (step === 3 && typeof hooks.onEnterStep3 === "function") {
    hooks.onEnterStep3();
  }

  if (step === 4 && typeof hooks.onEnterStep4 === "function") {
    hooks.onEnterStep4();
  }

  if (step === 5 && typeof hooks.onEnterStep5 === "function") {
    hooks.onEnterStep5();
  }
}
