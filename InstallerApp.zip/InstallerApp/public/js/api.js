import { parseJsonSafe, resolveAppPath } from "./utils.js";

export async function apiRequest(url, options = {}) {
  const request = {
    method: options.method || "GET",
    credentials: "include",
    headers: {
      ...(options.headers || {})
    }
  };

  if (options.body !== undefined) {
    const isFormDataBody =
      typeof FormData !== "undefined" && options.body instanceof FormData;

    if (isFormDataBody) {
      request.body = options.body;
    } else {
      request.headers["Content-Type"] = "application/json";
      request.body = JSON.stringify(options.body);
    }
  }

  const response = await fetch(resolveAppPath(url), request);
  const payload = await parseJsonSafe(response);

  if (!response.ok) {
    const error = new Error(payload?.message || `Request failed (${response.status})`);
    error.status = response.status;
    error.payload = payload;
    throw error;
  }

  return payload;
}
