const ABSOLUTE_URL_PATTERN = /^[a-z][a-z\d+\-.]*:\/\//i;

export function resolveAppPath(path = "") {
  const value = String(path || "").trim();
  if (!value) {
    return new URL(".", document.baseURI).toString();
  }

  if (ABSOLUTE_URL_PATTERN.test(value)) {
    return value;
  }

  const sanitized = value.replace(/^\/+/, "");
  return new URL(sanitized, document.baseURI).toString();
}

export async function parseJsonSafe(response) {
  const contentType = response.headers.get("content-type") || "";
  if (!contentType.toLowerCase().includes("application/json")) {
    return {};
  }

  try {
    return await response.json();
  } catch {
    return {};
  }
}