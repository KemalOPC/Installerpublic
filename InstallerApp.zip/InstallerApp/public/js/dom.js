export function getElements() {
  return {
    message: document.getElementById("message"),
    stepperItems: Array.from(document.querySelectorAll(".step-item")),
    pages: Array.from(document.querySelectorAll(".page")),

    loginForm: document.getElementById("login-form"),
    loginButton: document.getElementById("login-btn"),
    usernameInput: document.getElementById("username-input"),
    passwordInput: document.getElementById("password-input"),
    twoFaWrap: document.getElementById("twofa-wrap"),
    twoFaInput: document.getElementById("twofa-input"),
    resendTwoFaButton: document.getElementById("resend-twofa-btn"),

    logoutButton: document.getElementById("logout-btn"),
    userRoleChip: document.getElementById("user-role-chip"),

    step2Title: document.getElementById("step2-title"),
    step2Subtext: document.getElementById("step2-subtext"),
    adminModeChoice: document.getElementById("admin-mode-choice"),
    modeNewInstallButton: document.getElementById("mode-new-install-btn"),
    modeCheckExistingButton: document.getElementById("mode-check-existing-btn"),

    customerSearchInput: document.getElementById("customer-search-input"),
    customerList: document.getElementById("customer-list"),
    customerNextButton: document.getElementById("customer-next-btn"),

    adminSection: document.getElementById("admin-section"),
    adminDeviceSearchLabel: document.getElementById("admin-device-search-label"),
    adminDeviceSearchInput: document.getElementById("admin-device-search-input"),
    adminDeviceList: document.getElementById("admin-device-list"),

    techSection: document.getElementById("tech-section"),
    techImeiInput: document.getElementById("tech-imei-input"),
    techFindButton: document.getElementById("tech-find-btn"),
    techFindMessage: document.getElementById("tech-find-message"),

    selectedDevicePanel: document.getElementById("selected-device-panel"),
    selectedDeviceImei: document.getElementById("selected-device-imei"),
    selectedDeviceModel: document.getElementById("selected-device-model"),

    step3Title: document.getElementById("step3-title"),
    step3Subtext: document.getElementById("step3-subtext"),
    installFormWrap: document.getElementById("install-form-wrap"),

    vehicleLicenseInput: document.getElementById("vehicle-license-input"),
    vehicleVinInput: document.getElementById("vehicle-vin-input"),
    vehicleTypeInput: document.getElementById("vehicle-type-input"),
    vehicleNotesInput: document.getElementById("vehicle-notes-input"),
    installRequiredPanel: document.getElementById("install-required-panel"),
    installRequiredList: document.getElementById("install-required-list"),
    dynamicInstallFields: document.getElementById("dynamic-install-fields"),

    step3BackButton: document.getElementById("step3-back-btn"),
    step3NextButton: document.getElementById("step3-next-btn"),

    statusGps: document.getElementById("status-gps"),
    statusFuel: document.getElementById("status-fuel"),
    statusFuelCan: document.getElementById("status-fuel-can"),
    statusFuelCanTotal: document.getElementById("status-fuel-can-total"),
    statusVoltageSummary: document.getElementById("status-voltage-summary"),
    statusVoltageSupply: document.getElementById("status-voltage-supply"),
    statusLastUpdated: document.getElementById("status-last-updated"),
    refreshStatusButton: document.getElementById("refresh-status-btn"),
    runTachoButton: document.getElementById("run-tacho-btn"),
    tachoOutput: document.getElementById("tacho-output"),
    tachoStatusIndicator: document.getElementById("tacho-status-indicator"),
    tachoVehicleRegistration: document.getElementById("tacho-vehicle-registration"),
    tachoTotalDistance: document.getElementById("tacho-total-distance"),
    step5Title: document.getElementById("step5-title"),
    step5Subtext: document.getElementById("step5-subtext"),
    cameraQualityPanel: document.getElementById("camera-quality-panel"),
    cameraCapabilityMeta: document.getElementById("camera-capability-meta"),
    cameraCheckProgress: document.getElementById("camera-check-progress"),
    cameraCheckMounting: document.getElementById("camera-check-mounting"),
    cameraCheckVisibility: document.getElementById("camera-check-visibility"),
    cameraCheckPower: document.getElementById("camera-check-power"),
    cameraCheckOrientation: document.getElementById("camera-check-orientation"),

    step4BackButton: document.getElementById("step4-back-btn"),
    step4NextButton: document.getElementById("step4-next-btn"),

    summaryCustomer: document.getElementById("summary-customer"),
    summaryImei: document.getElementById("summary-imei"),
    summaryModel: document.getElementById("summary-model"),
    summaryLicense: document.getElementById("summary-license"),
    summaryVin: document.getElementById("summary-vin"),
    summaryVehicleType: document.getElementById("summary-vehicle-type"),

    step5BackButton: document.getElementById("step5-back-btn"),
    completeInstallButton: document.getElementById("complete-install-btn")
  };
}
