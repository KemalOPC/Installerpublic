export function renderModeChoice(elements, { isAdmin, flowMode, flowModes }) {
  elements.adminModeChoice.classList.toggle("hidden", !isAdmin);

  elements.modeNewInstallButton.classList.toggle(
    "selected",
    flowMode === flowModes.NEW_INSTALL
  );
  elements.modeCheckExistingButton.classList.toggle(
    "selected",
    flowMode === flowModes.CHECK_EXISTING
  );

  if (!isAdmin) {
    elements.step2Title.textContent = "Select Customer";
    elements.step2Subtext.textContent =
      "Only customers you are allowed to access are shown below, sorted alphabetically.";
    return;
  }

  elements.step2Title.textContent = "Choose Action And Customer";

  if (!flowMode) {
    elements.step2Subtext.textContent =
      "Choose New Install or Check Existing Device first, then select a customer.";
    return;
  }

  elements.step2Subtext.textContent =
    flowMode === flowModes.CHECK_EXISTING
      ? "Check Existing Device selected. Choose a customer to view installed devices."
      : "New Install selected. Choose a customer to continue the install workflow.";
}

export function renderStep3Layout(elements, { checkExisting }) {
  elements.step3Title.textContent = checkExisting
    ? "Select Existing Device"
    : "Device And Vehicle";

  elements.step3Subtext.textContent = checkExisting
    ? "Select an installed device for this customer, then run GPS, fuel, and tacho checks."
    : "Admin users can browse inventory. Technicians search by IMEI or serial number (S/N). Completing install will move the selected device from warehouse stock to installed.";

  elements.installFormWrap.classList.toggle("hidden", checkExisting);
  elements.step3NextButton.textContent = checkExisting
    ? "Run Status Check"
    : "Continue";

  elements.adminDeviceSearchLabel.textContent = checkExisting
    ? "Search Installed Devices"
    : "Search Warehouse Devices";
  elements.adminDeviceSearchInput.placeholder = checkExisting
    ? "Filter installed devices by IMEI, serial, or model"
    : "Filter by IMEI or model";
}

export function renderStatusLayout(elements, { checkExisting }) {
  elements.step5Title.textContent = "Status Check";
  elements.step5Subtext.textContent = checkExisting
    ? "Run status checks for the selected installed device."
    : "Run status checks after installation is completed.";
  elements.step4NextButton.textContent = checkExisting
    ? "Check Another Device"
    : "Start Next Install";
}

export function renderRoleSections(elements, { isAdmin, checkExisting }) {
  elements.adminSection.classList.toggle("hidden", !isAdmin);
  elements.techSection.classList.toggle("hidden", isAdmin || checkExisting);
}

export function renderCustomers(
  elements,
  {
    customers,
    selectedCustomerId,
    isAdmin,
    flowMode,
    flowModes,
    onSelectCustomer
  }
) {
  const query = elements.customerSearchInput.value.trim().toLowerCase();
  const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(query)
  );

  elements.customerList.innerHTML = "";

  if (filteredCustomers.length === 0) {
    const empty = document.createElement("li");
    empty.innerHTML =
      '<button class="selection-item-btn" type="button" disabled>No customers found</button>';
    elements.customerList.appendChild(empty);
    elements.customerNextButton.disabled = true;
    elements.customerNextButton.title = "Select a customer to continue.";
    return;
  }

  for (const customer of filteredCustomers) {
    const item = document.createElement("li");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "selection-item-btn";

    if (selectedCustomerId === customer.id) {
      button.classList.add("selected");
    }

    const title = document.createElement("span");
    title.className = "selection-title";
    title.textContent = customer.name;

    const meta = document.createElement("span");
    meta.className = "selection-meta";
    meta.textContent = `ID ${customer.id}`;

    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener("click", () => onSelectCustomer(customer));

    item.appendChild(button);
    elements.customerList.appendChild(item);
  }

  const requiresModeSelection = isAdmin && !flowMode;
  const missingCustomer = !selectedCustomerId;
  elements.customerNextButton.disabled = missingCustomer || requiresModeSelection;
  elements.customerNextButton.title = requiresModeSelection
    ? "Choose New Install or Check Existing Device first."
    : missingCustomer
      ? "Select a customer to continue."
      : "";

  // Keep a tiny guard in case callers pass inconsistent mode enums.
  if (flowMode && flowMode !== flowModes.NEW_INSTALL && flowMode !== flowModes.CHECK_EXISTING) {
    elements.customerNextButton.disabled = true;
    elements.customerNextButton.title = "Choose a valid workflow mode first.";
  }
}

export function renderAdminDevices(
  elements,
  { adminDevices, selectedDeviceId, checkExisting, onSelectDevice }
) {
  const query = elements.adminDeviceSearchInput.value.trim().toLowerCase();
  const devices = adminDevices.filter((device) => {
    if (!query) {
      return true;
    }

    const haystack = [
      device.imei || "",
      device.serial || "",
      device.display || "",
      device.model || "",
      device.registrationNumber || "",
      String(device.id)
    ]
      .join(" ")
      .toLowerCase();

    return haystack.includes(query);
  });

  elements.adminDeviceList.innerHTML = "";

  if (devices.length === 0) {
    const empty = document.createElement("li");
    empty.innerHTML =
      '<button class="selection-item-btn" type="button" disabled>No devices found</button>';
    elements.adminDeviceList.appendChild(empty);
    return;
  }

  for (const device of devices) {
    const item = document.createElement("li");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "selection-item-btn";

    if (selectedDeviceId === device.id) {
      button.classList.add("selected");
    }

    const title = document.createElement("span");
    title.className = "selection-title";
    title.textContent = checkExisting
      ? device.registrationNumber || "Registration unavailable"
      : device.imei || `Device #${device.id}`;

    const meta = document.createElement("span");
    meta.className = "selection-meta";
    meta.textContent = checkExisting
      ? `${device.imei || "No IMEI"} | ${device.model || "Unknown model"} | ID ${device.id}`
      : `${device.model || "Unknown model"} | ID ${device.id}`;

    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener("click", () => onSelectDevice(device));

    item.appendChild(button);
    elements.adminDeviceList.appendChild(item);
  }
}

export function renderSelectedDevice(elements, selectedDevice) {
  if (!selectedDevice) {
    elements.selectedDevicePanel.classList.add("hidden");
    return;
  }

  elements.selectedDevicePanel.classList.remove("hidden");
  elements.selectedDeviceImei.textContent =
    selectedDevice.imei || `Device #${selectedDevice.id}`;
  elements.selectedDeviceModel.textContent = selectedDevice.model || "Unknown model";
}

export function renderSummary(elements, { customer, selectedDevice, installForm }) {
  elements.summaryCustomer.textContent = customer?.name || "-";
  elements.summaryImei.textContent =
    selectedDevice?.imei || `Device #${selectedDevice?.id || "-"}`;
  elements.summaryModel.textContent = selectedDevice?.model || "-";
  elements.summaryLicense.textContent = installForm.licensePlate || "-";
  elements.summaryVin.textContent = installForm.vinNumber || "-";
  elements.summaryVehicleType.textContent = installForm.vehicleType || "-";
}
