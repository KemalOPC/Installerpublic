import fs from "node:fs";
import path from "node:path";

const HTTP_METHODS = ["get", "post", "put", "patch", "delete", "options", "head", "trace"];

const CATEGORY_BY_TAG = {
  Auth: "Authentication & Session Security",
  PermissionScopes: "Authentication & Session Security",

  Account: "Account, Users & Access Control",
  Users: "Account, Users & Access Control",
  UsersApi: "Account, Users & Access Control",
  UsersCompany: "Account, Users & Access Control",
  UserPresets: "Account, Users & Access Control",

  Companies: "Organizations, Distributors & Contacts",
  CompanyContacts: "Organizations, Distributors & Contacts",
  Distributors: "Organizations, Distributors & Contacts",
  AgreementTypes: "Organizations, Distributors & Contacts",
  Countries: "Organizations, Distributors & Contacts",
  ConDetails: "Organizations, Distributors & Contacts",

  Cars: "Device, Vehicle & Firmware Management",
  Devices: "Device, Vehicle & Firmware Management",
  SupportedDevices: "Device, Vehicle & Firmware Management",
  DevicesModels: "Device, Vehicle & Firmware Management",
  DevicesCommands: "Device, Vehicle & Firmware Management",
  DevicesImport: "Device, Vehicle & Firmware Management",
  DeviceCustomTargetGroup: "Device, Vehicle & Firmware Management",
  Firmware: "Device, Vehicle & Firmware Management",
  FuelRods: "Device, Vehicle & Firmware Management",
  UnitManagement: "Device, Vehicle & Firmware Management",

  MonitoringTool: "Fleet Monitoring, Telemetry & KPI",
  EtollMonitor: "Fleet Monitoring, Telemetry & KPI",
  KPI: "Fleet Monitoring, Telemetry & KPI",
  KpiSalesRevenue: "Fleet Monitoring, Telemetry & KPI",

  ClientProjects: "CRM Projects, Client Menus & Presets",
  ClientPresets: "CRM Projects, Client Menus & Presets",
  ClientMenu: "CRM Projects, Client Menus & Presets",
  ClientMenuGroups: "CRM Projects, Client Menus & Presets",
  Menu: "CRM Projects, Client Menus & Presets",

  SupportTasks: "Support, Jobs & Field Operations",
  SupportTasksRepairs: "Support, Jobs & Field Operations",
  SupportTasksInvoices: "Support, Jobs & Field Operations",
  SupportTasksInvoicesAttached: "Support, Jobs & Field Operations",
  SupportTasksNotifications: "Support, Jobs & Field Operations",
  SupportJobs: "Support, Jobs & Field Operations",
  SupportLocations: "Support, Jobs & Field Operations",
  Support: "Support, Jobs & Field Operations",

  Notifications: "Notifications, Alerts & Messaging",
  NotificationsManagement: "Notifications, Alerts & Messaging",
  PushApi: "Notifications, Alerts & Messaging",
  ClientProjectsNotifications: "Notifications, Alerts & Messaging",

  Orders: "Orders, Billing, Payments & Invoicing",
  Invoices: "Orders, Billing, Payments & Invoicing",
  PaymentMethods: "Orders, Billing, Payments & Invoicing",

  Products: "Inventory, Products, Packs & Marketplace",
  Packs: "Inventory, Products, Packs & Marketplace",
  Warehouse: "Inventory, Products, Packs & Marketplace",
  SimWarehouse: "Inventory, Products, Packs & Marketplace",
  ECommerce: "Inventory, Products, Packs & Marketplace",
  Shop: "Inventory, Products, Packs & Marketplace",
  MarketplaceAddon: "Inventory, Products, Packs & Marketplace",
  MarketplaceAddonDocs: "Inventory, Products, Packs & Marketplace",
  MarketplaceGroups: "Inventory, Products, Packs & Marketplace",
  Competitors: "Inventory, Products, Packs & Marketplace",
  CompaniesPack: "Inventory, Products, Packs & Marketplace",

  CompanyApiKeys: "Integrations, API Keys & Custom Commands",
  CustomMappings: "Integrations, API Keys & Custom Commands",
  CustomCommands: "Integrations, API Keys & Custom Commands",

  Attachments: "Content, Documentation & Localization",
  Documentation: "Content, Documentation & Localization",
  Translations: "Content, Documentation & Localization",

  Helpers: "Platform Utilities, Search & System Ops",
  Batch: "Platform Utilities, Search & System Ops",
  BackgroundProcess: "Platform Utilities, Search & System Ops",
  System: "Platform Utilities, Search & System Ops",
  Search: "Platform Utilities, Search & System Ops",
  AuditLog: "Platform Utilities, Search & System Ops",
  PublicTool: "Platform Utilities, Search & System Ops",
};

const METHOD_ORDER = {
  GET: 1,
  POST: 2,
  PUT: 3,
  PATCH: 4,
  DELETE: 5,
  OPTIONS: 6,
  HEAD: 7,
  TRACE: 8,
};

const CROSS_CUTTING_PREFIXES = [
  "/batch",
  "/bg-process",
  "/helpers",
  "/search",
  "/system",
  "/public-tool",
  "/audit-log",
];

function toMarkdownCell(value) {
  return String(value ?? "")
    .replace(/\|/g, "\\|")
    .replace(/\r?\n/g, " ")
    .trim();
}

function firstLine(value) {
  if (!value) {
    return "";
  }
  return String(value).split(/\r?\n/)[0].trim();
}

function inferCategoryByPath(endpointPath) {
  if (endpointPath.startsWith("/auth") || endpointPath.includes("permission")) {
    return "Authentication & Session Security";
  }
  if (endpointPath.startsWith("/account") || endpointPath.startsWith("/users")) {
    return "Account, Users & Access Control";
  }
  if (endpointPath.startsWith("/cars") || endpointPath.startsWith("/devices") || endpointPath.startsWith("/firmware")) {
    return "Device, Vehicle & Firmware Management";
  }
  if (endpointPath.startsWith("/client-projects") || endpointPath.startsWith("/client-menu")) {
    return "CRM Projects, Client Menus & Presets";
  }
  if (endpointPath.startsWith("/notifications") || endpointPath.includes("notification")) {
    return "Notifications, Alerts & Messaging";
  }
  if (endpointPath.startsWith("/orders") || endpointPath.startsWith("/invoices") || endpointPath.startsWith("/payment-methods")) {
    return "Orders, Billing, Payments & Invoicing";
  }
  return "Platform Utilities, Search & System Ops";
}

function resolveCategory(primaryTag, endpointPath) {
  if (primaryTag && CATEGORY_BY_TAG[primaryTag]) {
    return {
      category: CATEGORY_BY_TAG[primaryTag],
      note: CROSS_CUTTING_PREFIXES.some((prefix) => endpointPath.startsWith(prefix))
        ? "Cross-cutting utility endpoint."
        : "",
    };
  }

  const inferred = inferCategoryByPath(endpointPath);
  if (primaryTag) {
    return {
      category: inferred,
      note: `Unmapped source tag (${primaryTag}) assigned by path rule.`,
    };
  }

  return {
    category: inferred,
    note: "No source tag in spec; assigned by path rule.",
  };
}

function collectEndpoints(paths) {
  const endpoints = [];

  for (const [endpointPath, pathNode] of Object.entries(paths)) {
    for (const [method, operation] of Object.entries(pathNode ?? {})) {
      const lowerMethod = method.toLowerCase();
      if (!HTTP_METHODS.includes(lowerMethod)) {
        continue;
      }

      const tags = Array.isArray(operation.tags) ? operation.tags.filter(Boolean) : [];
      const primaryTag = tags[0] ?? "";
      const { category, note } = resolveCategory(primaryTag, endpointPath);

      endpoints.push({
        category,
        method: lowerMethod.toUpperCase(),
        endpointPath,
        primaryTag: primaryTag || "UnTagged",
        operationId: operation.operationId || "",
        purpose: operation.summary || firstLine(operation.description) || operation.operationId || "",
        note,
      });
    }
  }

  return endpoints.sort((a, b) => {
    const byCategory = a.category.localeCompare(b.category);
    if (byCategory !== 0) {
      return byCategory;
    }

    const byPath = a.endpointPath.localeCompare(b.endpointPath);
    if (byPath !== 0) {
      return byPath;
    }

    return (METHOD_ORDER[a.method] || 99) - (METHOD_ORDER[b.method] || 99);
  });
}

function buildMarkdown(endpoints, sourcePath) {
  const generatedAt = new Date().toISOString();
  const categoryCounts = new Map();
  const tagsByCategory = new Map();

  for (const endpoint of endpoints) {
    categoryCounts.set(endpoint.category, (categoryCounts.get(endpoint.category) || 0) + 1);

    const currentTags = tagsByCategory.get(endpoint.category) || new Set();
    if (endpoint.primaryTag && endpoint.primaryTag !== "UnTagged") {
      currentTags.add(endpoint.primaryTag);
    }
    tagsByCategory.set(endpoint.category, currentTags);
  }

  const summaryRows = Array.from(categoryCounts.entries()).sort((a, b) => {
    if (b[1] !== a[1]) {
      return b[1] - a[1];
    }
    return a[0].localeCompare(b[0]);
  });

  const lines = [];
  lines.push("# API Endpoint Categorization");
  lines.push("");
  lines.push(`Source: ${sourcePath}`);
  lines.push(`Generated: ${generatedAt}`);
  lines.push(`Total endpoints: ${endpoints.length}`);
  lines.push("");
  lines.push("## Category Summary");
  lines.push("");
  lines.push("| Category | Endpoint count | Source tags | Focus use case |");
  lines.push("| --- | ---: | --- | --- |");

  for (const [category, count] of summaryRows) {
    const tags = Array.from(tagsByCategory.get(category) || []).sort().join(", ");
    let focus = "";

    if (category === "Authentication & Session Security") {
      focus = "User login, token lifecycle, 2FA, permission scopes.";
    } else if (category === "Account, Users & Access Control") {
      focus = "Account profile, permissions, user and preset administration.";
    } else if (category === "Device, Vehicle & Firmware Management") {
      focus = "Vehicle onboarding, device lifecycle, firmware and unit operations.";
    } else if (category === "CRM Projects, Client Menus & Presets") {
      focus = "Client/project workflows, menu configuration, operational presets.";
    } else if (category === "Notifications, Alerts & Messaging") {
      focus = "Operational alerts, outbound messaging and notification controls.";
    } else if (category === "Orders, Billing, Payments & Invoicing") {
      focus = "Commercial transactions, payment methods and invoice operations.";
    } else {
      focus = "Domain-specific operations grouped by source tags and endpoint intent.";
    }

    lines.push(`| ${toMarkdownCell(category)} | ${count} | ${toMarkdownCell(tags)} | ${toMarkdownCell(focus)} |`);
  }

  lines.push("");
  lines.push("## Complete Endpoint Mapping");
  lines.push("");
  lines.push("| Category | Method | Endpoint | Source tag | Operation ID | Purpose | Notes |");
  lines.push("| --- | --- | --- | --- | --- | --- | --- |");

  for (const endpoint of endpoints) {
    lines.push(
      `| ${toMarkdownCell(endpoint.category)} | ${endpoint.method} | ${toMarkdownCell(endpoint.endpointPath)} | ${toMarkdownCell(endpoint.primaryTag)} | ${toMarkdownCell(endpoint.operationId)} | ${toMarkdownCell(endpoint.purpose)} | ${toMarkdownCell(endpoint.note)} |`,
    );
  }

  return `${lines.join("\n")}\n`;
}

function main() {
  const workspaceRoot = process.cwd();
  const inputPath = path.join(workspaceRoot, "api-1.json");
  const outputPath = path.join(workspaceRoot, "endpoint-categories.md");

  const raw = fs.readFileSync(inputPath, "utf8");
  const spec = JSON.parse(raw);
  const paths = spec.paths || {};
  const endpoints = collectEndpoints(paths);
  const markdown = buildMarkdown(endpoints, "api-1.json");

  fs.writeFileSync(outputPath, markdown, "utf8");

  const uniqueTags = new Set(endpoints.map((row) => row.primaryTag).filter((tag) => tag !== "UnTagged"));
  console.log(`Generated endpoint-categories.md with ${endpoints.length} endpoints across ${new Set(endpoints.map((row) => row.category)).size} categories.`);
  console.log(`Covered source tags: ${uniqueTags.size}`);
}

main();