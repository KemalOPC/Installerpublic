import express from "express";
import session from "express-session";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || "development";
const SESSION_SECRET = process.env.SESSION_SECRET || "replace-this-session-secret";
const SESSION_COOKIE = "installer.sid";
const CRM_API_BASE_URL = String(
  process.env.CRM_API_BASE_URL || "https://example.com/crm-api"
).replace(/\/+$/, "");
const RECENT_DATA_TOLERANCE_MS = 2 * 60 * 60 * 1000;
const CAMERA_CAPABILITY_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

const cameraCapabilityCache = new Map();

const CAMERA_KEYWORD_PATTERN =
  /(^|[^a-z0-9])(camera|dashcam|dash cam|mdvr|dvr|nvr|roadcam|dualcam|cam)([^a-z0-9]|$)/i;

const allowedOrigins = new Set(
  String(process.env.ALLOWED_ORIGINS || `http://localhost:${PORT}`)
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean)
);

const app = express();

app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        baseUri: ["'self'"]
      }
    }
  })
);

app.use(express.json({ limit: "1mb" }));

app.use(
  session({
    name: SESSION_COOKIE,
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 1000 * 60 * 60 * 8
    }
  })
);

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 250,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many requests. Please try again shortly." }
});

const loginLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many login attempts. Please wait and retry." }
});

function isOriginAllowed(req) {
  const origin = req.get("origin");
  if (!origin) {
    return true;
  }

  if (allowedOrigins.has(origin)) {
    return true;
  }

  const sameOrigin = `${req.protocol}://${req.get("host")}`;
  return origin === sameOrigin;
}

function getApiUrl(endpoint) {
  const safePath = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  return `${CRM_API_BASE_URL}${safePath}`;
}

function parseTokenCandidate(value) {
  if (!value || typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  const bearerMatch = trimmed.match(/^Bearer\s+(.+)$/i);
  if (bearerMatch?.[1]) {
    return bearerMatch[1].trim();
  }

  if (!trimmed || /\s/.test(trimmed)) {
    return null;
  }

  if (/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(trimmed)) {
    return trimmed;
  }

  if (trimmed.length >= 16) {
    return trimmed;
  }

  return null;
}

function extractTokenFromHeaders(headers) {
  const keys = [
    "authorization",
    "Authorization",
    "x-auth-token",
    "app-auth-token",
    "token"
  ];

  for (const key of keys) {
    const token = parseTokenCandidate(headers.get(key));
    if (token) {
      return token;
    }
  }

  return null;
}

function extractTokenFromPayload(payload) {
  const candidates = [
    payload?.token,
    payload?.access_token,
    payload?.accessToken,
    payload?.jwt,
    payload?.authToken,
    payload?.data?.token,
    payload?.data?.access_token,
    payload?.data?.accessToken,
    payload?.data?.jwt,
    payload?.data?.authToken
  ];

  for (const candidate of candidates) {
    const token = parseTokenCandidate(candidate);
    if (token) {
      return token;
    }
  }

  return null;
}

function extractMessage(payload) {
  if (!payload) {
    return "Unexpected API response.";
  }

  if (typeof payload === "string") {
    return payload;
  }

  if (typeof payload.message === "string") {
    return payload.message;
  }

  if (typeof payload.data?.message === "string") {
    return payload.data.message;
  }

  if (typeof payload.error?.message === "string") {
    return payload.error.message;
  }

  if (payload.errors && typeof payload.errors === "object") {
    const firstKey = Object.keys(payload.errors)[0];
    const firstValue = payload.errors[firstKey];
    if (Array.isArray(firstValue) && firstValue.length > 0) {
      return String(firstValue[0]);
    }
    if (typeof firstValue === "string") {
      return firstValue;
    }
  }

  return "Request failed.";
}

function looksLikeTwoFactorRequired(payload) {
  if (!payload) {
    return false;
  }

  const body = JSON.stringify(payload).toLowerCase();
  return (
    body.includes("twofactorauthcode") ||
    body.includes("two factor") ||
    body.includes("2fa") ||
    body.includes("auth_app")
  );
}

function looksLikeDeviceNotInstalled(payload) {
  if (!payload) {
    return false;
  }

  const message = extractMessage(payload).toLowerCase();
  const body = JSON.stringify(payload).toLowerCase();

  return (
    message.includes("not installed") ||
    body.includes("not installed") ||
    body.includes("device is not installed")
  );
}

function normalizeSignalValue(value) {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value === "number") {
    return value > 0;
  }

  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (!normalized) {
      return false;
    }

    if (
      ["true", "1", "yes", "on", "ok", "active", "connected", "receiving"].includes(
        normalized
      )
    ) {
      return true;
    }

    if (
      ["false", "0", "no", "off", "inactive", "disconnected", "n/a", "na"].includes(
        normalized
      )
    ) {
      return false;
    }

    const numericValue = Number(normalized);
    if (Number.isFinite(numericValue)) {
      return numericValue > 0;
    }

    return false;
  }

  if (value && typeof value === "object") {
    if (Object.hasOwn(value, "value")) {
      return normalizeSignalValue(value.value);
    }

    if (Object.hasOwn(value, "status")) {
      return normalizeSignalValue(value.status);
    }

    if (Object.hasOwn(value, "state")) {
      return normalizeSignalValue(value.state);
    }

    if (Object.hasOwn(value, "connected")) {
      return normalizeSignalValue(value.connected);
    }
  }

  return false;
}

function toTimestampMs(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return value < 1e12 ? value * 1000 : value;
  }

  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) {
      return null;
    }

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) {
      return numeric < 1e12 ? numeric * 1000 : numeric;
    }

    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function getLastDataTimestampMs(lastDataReceived) {
  if (!lastDataReceived || typeof lastDataReceived !== "object") {
    return null;
  }

  const fromTs = toTimestampMs(lastDataReceived.ts);
  if (fromTs !== null) {
    return fromTs;
  }

  const fromRaw = toTimestampMs(lastDataReceived.raw);
  if (fromRaw !== null) {
    return fromRaw;
  }

  return toTimestampMs(lastDataReceived.localized);
}

function isLastDataRecent(lastDataReceived, nowMs = Date.now()) {
  const timestampMs = getLastDataTimestampMs(lastDataReceived);
  if (timestampMs === null) {
    return false;
  }

  const ageMs = nowMs - timestampMs;
  if (ageMs < 0) {
    return false;
  }

  return ageMs <= RECENT_DATA_TOLERANCE_MS;
}

function normalizeList(payload) {
  if (Array.isArray(payload?.data)) {
    return payload.data;
  }
  if (Array.isArray(payload)) {
    return payload;
  }
  return [];
}

function getPaginationMeta(payload) {
  const pagination = payload?.meta?.pagination || payload?.meta || {};
  const totalPagesRaw = Number(
    pagination.totalPages || pagination.total_pages || 1
  );
  const currentPageRaw = Number(
    pagination.currentPage || pagination.current_page || 1
  );

  return {
    totalPages:
      Number.isFinite(totalPagesRaw) && totalPagesRaw > 0 ? totalPagesRaw : 1,
    currentPage:
      Number.isFinite(currentPageRaw) && currentPageRaw > 0 ? currentPageRaw : 1
  };
}

function normalizeInstallOptions(payload) {
  const source =
    payload?.data && typeof payload.data === "object" ? payload.data : payload || {};

  const requiredFieldsInstall = Array.isArray(source.requiredFieldsInstall)
    ? Array.from(
        new Set(
          source.requiredFieldsInstall
            .filter((value) => typeof value === "string")
            .map((value) => value.trim())
            .filter(Boolean)
        )
      )
    : [];

  const vehicleTypes = Array.isArray(source.vehicleTypes)
    ? source.vehicleTypes
        .map((item) => ({
          id: String(item?.id || "").trim(),
          title: String(item?.title || item?.id || "").trim()
        }))
        .filter((item) => item.id)
    : [];

  return {
    requiredFieldsInstall,
    vehicleTypes
  };
}

function toOptionalString(value) {
  if (value === undefined || value === null) {
    return "";
  }
  return String(value).trim();
}

function toAdditionalInstallFields(rawValue) {
  if (!rawValue || typeof rawValue !== "object" || Array.isArray(rawValue)) {
    return {};
  }

  const output = {};

  for (const [key, value] of Object.entries(rawValue)) {
    const fieldName = String(key || "").trim();
    if (!fieldName) {
      continue;
    }

    if (value === undefined || value === null) {
      continue;
    }

    if (typeof value === "string") {
      const normalized = value.trim();
      if (normalized) {
        output[fieldName] = normalized;
      }
      continue;
    }

    if (typeof value === "number" && Number.isFinite(value)) {
      output[fieldName] = value;
      continue;
    }

    if (typeof value === "boolean") {
      output[fieldName] = value;
    }
  }

  return output;
}

function extractImeiFromText(value) {
  if (!value || typeof value !== "string") {
    return null;
  }
  const match = value.match(/\b\d{14,17}\b/);
  return match ? match[0] : null;
}

const KNOWN_ACCOUNT_TYPES = new Set(["admin", "user", "user_all"]);

function normalizeIdentityTokens(value) {
  if (value === undefined || value === null) {
    return [];
  }

  if (Array.isArray(value)) {
    return Array.from(
      new Set(value.flatMap((entry) => normalizeIdentityTokens(entry)))
    );
  }

  if (typeof value === "object") {
    const enabledKeys = [];
    for (const [key, enabled] of Object.entries(value)) {
      const normalizedEnabled =
        enabled === true ||
        enabled === 1 ||
        (typeof enabled === "string" && enabled.trim().toLowerCase() === "true");

      if (!normalizedEnabled) {
        continue;
      }

      enabledKeys.push(...normalizeIdentityTokens(key));
    }

    return Array.from(new Set(enabledKeys));
  }

  const raw = String(value).trim().toLowerCase();
  if (!raw) {
    return [];
  }

  const tokens = raw
    .split(/[;,|]+/)
    .map((token) => token.trim())
    .filter(Boolean);

  return Array.from(new Set(tokens.length > 0 ? tokens : [raw]));
}

function normalizeRoles(value) {
  if (value === undefined || value === null) {
    return [];
  }

  if (Array.isArray(value) || typeof value === "string") {
    return normalizeIdentityTokens(value);
  }

  if (typeof value !== "object") {
    return [];
  }

  const enabledRoles = [];
  for (const [roleName, enabled] of Object.entries(value)) {
    const normalizedEnabled =
      enabled === true ||
      enabled === 1 ||
      (typeof enabled === "string" && enabled.trim().toLowerCase() === "true");

    if (!normalizedEnabled) {
      continue;
    }

    enabledRoles.push(...normalizeIdentityTokens(roleName));
  }

  return Array.from(new Set(enabledRoles));
}

function getUserPayload(source) {
  if (!source || typeof source !== "object") {
    return {};
  }

  if (source.data && typeof source.data === "object" && !Array.isArray(source.data)) {
    return source.data;
  }

  return source;
}

function toUserProfile(accountData = null, authUserData = null) {
  const account = getUserPayload(accountData);
  const authUser = getUserPayload(authUserData);

  const rawTypeValue =
    account?.type ??
    account?.accountType ??
    authUser?.type ??
    authUser?.accountType ??
    "user";
  const rawTypeTokens = normalizeIdentityTokens(rawTypeValue);

  const accountTypes = Array.from(
    new Set(rawTypeTokens.filter((token) => KNOWN_ACCOUNT_TYPES.has(token)))
  );

  const primaryType = accountTypes[0] || "user";

  const fallbackRolesFromType = rawTypeTokens.filter(
    (token) => !KNOWN_ACCOUNT_TYPES.has(token)
  );

  const explicitRoles = [
    ...normalizeRoles(account?.roles),
    ...normalizeRoles(account?.role),
    ...normalizeRoles(account?.userRoles),
    ...normalizeRoles(authUser?.roles),
    ...normalizeRoles(authUser?.role),
    ...normalizeRoles(authUser?.userRoles)
  ];

  let roles = Array.from(
    new Set([...fallbackRolesFromType, ...explicitRoles])
  ).filter((token) => !KNOWN_ACCOUNT_TYPES.has(token));

  const isAdmin =
    accountTypes.includes("admin") || rawTypeTokens.includes("admin");

  const derivedRole = isAdmin ? "admin" : "technician";
  if (roles.length === 0 && derivedRole !== primaryType) {
    roles = [derivedRole];
  }

  const fullName = [
    account?.name ?? authUser?.name,
    account?.surname ?? authUser?.surname
  ]
    .filter(Boolean)
    .join(" ")
    .trim();

  return {
    id: account?.id ?? authUser?.id ?? null,
    name: fullName || null,
    type: primaryType,
    accountTypes: accountTypes.length > 0 ? accountTypes : [primaryType],
    roles,
    isAdmin,
    role: isAdmin ? "admin" : "technician"
  };
}

async function fetchRealUserRoles(req, userId) {
  const normalizedUserId = Number(userId);
  if (!Number.isInteger(normalizedUserId) || normalizedUserId <= 0) {
    return [];
  }

  const userResponse = await crmFetch(req, `/users/${normalizedUserId}`, {
    method: "GET"
  });

  if (!userResponse.ok) {
    return [];
  }

  const userData = getUserPayload(userResponse.payload);
  return Array.from(
    new Set([
      ...normalizeRoles(userData?.roles),
      ...normalizeRoles(userData?.role),
      ...normalizeRoles(userData?.userRoles)
    ])
  ).filter((token) => !KNOWN_ACCOUNT_TYPES.has(token));
}

async function buildCurrentUserProfile(req, accountPayload, authUserPayload = null) {
  const baseProfile = toUserProfile(accountPayload, authUserPayload);
  const realRoles = await fetchRealUserRoles(req, baseProfile.id);

  if (realRoles.length === 0) {
    return baseProfile;
  }

  return {
    ...baseProfile,
    roles: realRoles
  };
}

function normalizeSearchText(value) {
  return toOptionalString(value)
    .toLowerCase()
    .replace(/[_\-.]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function hasCameraKeyword(value, pattern = CAMERA_KEYWORD_PATTERN) {
  const normalized = normalizeSearchText(value);
  if (!normalized) {
    return false;
  }

  return pattern.test(normalized);
}

function getCameraCapabilityCacheKey(deviceData = {}) {
  return [
    deviceData?.model,
    deviceData?.modelVersion,
    deviceData?.modelCode,
    deviceData?.productCode
  ]
    .map((value) => normalizeSearchText(value))
    .join("|");
}

function getCachedCameraCapability(cacheKey) {
  if (!cacheKey) {
    return null;
  }

  const cached = cameraCapabilityCache.get(cacheKey);
  if (!cached) {
    return null;
  }

  if (cached.expiresAt <= Date.now()) {
    cameraCapabilityCache.delete(cacheKey);
    return null;
  }

  return cached.value;
}

function setCachedCameraCapability(cacheKey, value) {
  if (!cacheKey) {
    return;
  }

  if (cameraCapabilityCache.size > 1500) {
    cameraCapabilityCache.clear();
  }

  cameraCapabilityCache.set(cacheKey, {
    expiresAt: Date.now() + CAMERA_CAPABILITY_CACHE_TTL_MS,
    value
  });
}

function buildCameraCapability({
  isCamera = false,
  source = "unknown",
  confidence = "low",
  reasons = []
} = {}) {
  return {
    isCamera: Boolean(isCamera),
    requiresChecklist: Boolean(isCamera),
    source,
    confidence,
    reasons: Array.from(new Set(reasons.filter(Boolean))).slice(0, 8)
  };
}

function getCameraHeuristicReasons(deviceData = {}) {
  const candidates = [
    ["model", deviceData?.model],
    ["modelCode", deviceData?.modelCode],
    ["productCode", deviceData?.productCode],
    ["modelVersion", deviceData?.modelVersion]
  ];

  const reasons = [];

  for (const [fieldName, value] of candidates) {
    if (hasCameraKeyword(value)) {
      reasons.push(`${fieldName}:${toOptionalString(value)}`);
    }
  }

  return reasons;
}

async function resolveCameraCapability(_req, deviceData = {}, requestCache = null) {
  const cacheKey = getCameraCapabilityCacheKey(deviceData);
  const hasIdentity = cacheKey.replace(/\|/g, "").length > 0;

  if (!hasIdentity) {
    return buildCameraCapability({
      isCamera: false,
      source: "unknown",
      confidence: "low",
      reasons: ["missing-model-data"]
    });
  }

  if (requestCache?.has(cacheKey)) {
    return requestCache.get(cacheKey);
  }

  const capabilityPromise = (async () => {
    const cached = getCachedCameraCapability(cacheKey);
    if (cached) {
      return cached;
    }

    // ponytail: model-keyword heuristic only; add supported-model lookup if false negatives become a real issue.
    const heuristicReasons = getCameraHeuristicReasons(deviceData);

    const capability = buildCameraCapability({
      isCamera: heuristicReasons.length > 0,
      source: "model-heuristic",
      confidence: heuristicReasons.length > 0 ? "medium" : "low",
      reasons: heuristicReasons
    });

    setCachedCameraCapability(cacheKey, capability);
    return capability;
  })();

  if (requestCache) {
    requestCache.set(cacheKey, capabilityPromise);
  }

  return capabilityPromise;
}

function clearAuthSession(req) {
  delete req.session.crmToken;
  delete req.session.user;
}

function saveSession(req) {
  return new Promise((resolve, reject) => {
    req.session.save((error) => {
      if (error) {
        reject(error);
        return;
      }
      resolve();
    });
  });
}

async function crmFetch(req, endpoint, options = {}) {
  const headers = new Headers(options.headers || {});

  if (options.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (req.session.crmToken && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${req.session.crmToken}`);
  }

  let response;
  try {
    response = await fetch(getApiUrl(endpoint), {
      method: options.method || "GET",
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined
    });
  } catch (error) {
    return {
      ok: false,
      status: 503,
      payload: {
        message: "CRM API unreachable.",
        details: String(error)
      }
    };
  }

  const rotatedToken = extractTokenFromHeaders(response.headers);
  if (rotatedToken) {
    req.session.crmToken = rotatedToken;
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!rotatedToken) {
    const payloadToken = extractTokenFromPayload(payload);
    if (payloadToken) {
      req.session.crmToken = payloadToken;
    }
  }

  return {
    ok: response.ok,
    status: response.status,
    payload,
    headers: response.headers
  };
}

function sendUpstreamError(res, upstream, fallbackMessage) {
  const status = Number.isInteger(upstream?.status) ? upstream.status : 500;
  return res.status(status).json({
    message: extractMessage(upstream?.payload) || fallbackMessage,
    details: upstream?.payload || null
  });
}

function requireAuth(req, res, next) {
  if (!req.session.crmToken) {
    return res.status(401).json({ message: "Authentication required." });
  }
  return next();
}

function requireAdmin(req, res, next) {
  const user = req.session.user;
  const accountTypes = normalizeIdentityTokens(user?.accountTypes);
  const userTypes = normalizeIdentityTokens(user?.type);
  const role = String(user?.role || "").trim().toLowerCase();

  const isAdmin =
    user?.isAdmin === true ||
    accountTypes.includes("admin") ||
    userTypes.includes("admin") ||
    role === "admin";

  if (!isAdmin) {
    return res.status(403).json({ message: "Admin permission is required." });
  }

  return next();
}

app.use("/api", (req, res, next) => {
  if (!isOriginAllowed(req)) {
    return res.status(403).json({ message: "Origin is not allowed." });
  }
  return next();
});

app.use("/api", apiLimiter);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/auth/login", loginLimiter, async (req, res) => {
  const username = String(req.body?.username || "").trim();
  const password = String(req.body?.password || "");
  const twoFactorCodeRaw = String(req.body?.twoFactorCode || "").trim();

  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required." });
  }

  const authPayload = { username, password };

  if (twoFactorCodeRaw) {
    const twoFactorCode = Number(twoFactorCodeRaw);
    if (!Number.isInteger(twoFactorCode)) {
      return res.status(400).json({ message: "Two-factor code must be numeric." });
    }
    authPayload.twoFactorAuthCode = twoFactorCode;
  }

  const authResponse = await crmFetch(req, "/auth/token", {
    method: "POST",
    body: authPayload
  });

  if (authResponse.ok) {
    if (!req.session.crmToken) {
      const authToken = extractTokenFromPayload(authResponse.payload);
      if (authToken) {
        req.session.crmToken = authToken;
      }
    }

    if (!req.session.crmToken) {
      clearAuthSession(req);
      return res.status(502).json({
        message: "Authentication token was not returned by CRM API.",
        details: authResponse.payload || null
      });
    }

    const accountResponse = await crmFetch(req, "/account", { method: "GET" });
    const profile = accountResponse.ok
      ? await buildCurrentUserProfile(
          req,
          accountResponse.payload,
          authResponse.payload?.user
        )
      : toUserProfile(null, authResponse.payload?.user);

    req.session.user = profile;

    try {
      await saveSession(req);
    } catch {
      clearAuthSession(req);
      return res.status(500).json({
        message: "Unable to persist authenticated session. Please retry."
      });
    }

    return res.status(200).json({
      authenticated: true,
      requiresTwoFactor: false,
      user: profile
    });
  }

  if (!twoFactorCodeRaw) {
    if (looksLikeTwoFactorRequired(authResponse.payload)) {
      return res.status(200).json({
        authenticated: false,
        requiresTwoFactor: true,
        message: "Two-factor authentication code required."
      });
    }

    if (authResponse.status === 401 || authResponse.status === 422) {
      const twoFaSendResponse = await crmFetch(req, "/auth/twofa/send-code", {
        method: "POST",
        body: { username, password }
      });

      if (twoFaSendResponse.ok) {
        return res.status(200).json({
          authenticated: false,
          requiresTwoFactor: true,
          message: "Two-factor code sent. Enter your code to continue."
        });
      }
    }
  }

  clearAuthSession(req);
  return sendUpstreamError(res, authResponse, "Login failed.");
});

app.post("/api/auth/send-2fa", loginLimiter, async (req, res) => {
  const username = String(req.body?.username || "").trim();
  const password = String(req.body?.password || "");
  const channel = String(req.body?.channel || "").trim();

  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required." });
  }

  const payload = { username, password };
  if (channel === "email" || channel === "sms") {
    payload.channel = channel;
  }

  const response = await crmFetch(req, "/auth/twofa/send-code", {
    method: "POST",
    body: payload
  });

  if (!response.ok) {
    return sendUpstreamError(res, response, "Unable to send 2FA code.");
  }

  return res.json({ success: true });
});

app.get("/api/session", async (req, res) => {
  if (!req.session.crmToken) {
    return res.json({ authenticated: false });
  }

  const accountResponse = await crmFetch(req, "/account", { method: "GET" });

  if (accountResponse.ok) {
    const normalizedUser = await buildCurrentUserProfile(
      req,
      accountResponse.payload,
      req.session.user
    );
    req.session.user = normalizedUser;

    return res.json({
      authenticated: true,
      user: normalizedUser
    });
  }

  if (accountResponse.status === 401 || accountResponse.status === 403) {
    clearAuthSession(req);
    return res.json({ authenticated: false });
  }

  const normalizedUser = req.session.user
    ? toUserProfile(req.session.user, req.session.user)
    : null;
  req.session.user = normalizedUser;

  return res.json({
    authenticated: true,
    user: normalizedUser
  });
});

app.post("/api/auth/logout", async (req, res) => {
  if (req.session.crmToken) {
    await crmFetch(req, "/auth/token/invalidate", { method: "GET" });
  }

  req.session.destroy(() => {
    res.clearCookie(SESSION_COOKIE);
    res.json({ success: true });
  });
});

app.get("/api/account", requireAuth, async (req, res) => {
  const response = await crmFetch(req, "/account", { method: "GET" });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      clearAuthSession(req);
    }
    return sendUpstreamError(res, response, "Unable to read account data.");
  }

  const profile = await buildCurrentUserProfile(req, response.payload, req.session.user);
  req.session.user = profile;

  return res.json({
    user: profile,
    account: response.payload
  });
});

app.get("/api/install/options", requireAuth, async (req, res) => {
  const response = await crmFetch(req, "/cars/options", { method: "GET" });
  if (!response.ok) {
    return sendUpstreamError(res, response, "Unable to fetch install options.");
  }

  return res.json({ data: normalizeInstallOptions(response.payload) });
});

app.get("/api/customers", requireAuth, async (req, res) => {
  const query = String(req.query?.query || "").trim();

  let page = 1;
  let totalPages = 1;
  const collected = [];

  do {
    const endpoint =
      `/companies?limit=100&page=${page}` +
      (query ? `&query=${encodeURIComponent(query)}` : "");

    const response = await crmFetch(req, endpoint, { method: "GET" });
    if (!response.ok) {
      return sendUpstreamError(res, response, "Unable to fetch customers.");
    }

    const companies = normalizeList(response.payload)
      .map((company) => ({
        id: Number(company?.id),
        name: String(company?.name || "").trim(),
        status: company?.status || null
      }))
      .filter(
        (company) => Number.isInteger(company.id) && company.id > 0 && company.name
      );

    collected.push(...companies);

    const pagination = getPaginationMeta(response.payload);
    totalPages = pagination.totalPages;
    page += 1;
  } while (page <= totalPages && page <= 30);

  const deduplicated = Array.from(
    new Map(collected.map((company) => [company.id, company])).values()
  ).sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));

  return res.json({ data: deduplicated });
});

app.get("/api/devices/company/:companyId", requireAuth, async (req, res) => {
  const companyId = Number(req.params.companyId);
  const search = String(req.query?.search || "").trim().toLowerCase();

  if (!Number.isInteger(companyId) || companyId <= 0) {
    return res.status(400).json({ message: "Valid companyId is required." });
  }

  const stockResponse = await crmFetch(
    req,
    `/devices/companies/${companyId}/stock`,
    { method: "GET" }
  );

  if (!stockResponse.ok) {
    return sendUpstreamError(
      res,
      stockResponse,
      "Unable to fetch company stock devices."
    );
  }

  const stockDevices = normalizeList(stockResponse.payload);
  const capabilityLookupPromises = new Map();

  const enrichedDevices = await Promise.all(
    stockDevices.map(async (item) => {
      const detailResponse = await crmFetch(req, `/devices/${item.id}`, {
        method: "GET"
      });
      const detail = detailResponse.ok ? detailResponse.payload?.data || {} : {};

      const deviceData = {
        id: Number(item?.id),
        imei: detail?.imei || extractImeiFromText(item?.display) || null,
        serial: detail?.serial || null,
        model: item?.model || detail?.model || null,
        modelCode: item?.modelCode || detail?.modelCode || null,
        modelVersion: item?.modelVersion || detail?.modelVersion || null,
        productCode: detail?.productCode || item?.productCode || null,
        status: detail?.status || item?.status || null,
        display: item?.display || null,
        location: item?.location || null,
        locationDisplay: item?.locationDisplay || null
      };

      deviceData.cameraCapability = await resolveCameraCapability(
        req,
        deviceData,
        capabilityLookupPromises
      );

      return deviceData;
    })
  );

  const filteredDevices = enrichedDevices
    .filter((device) => Number.isInteger(device.id) && device.id > 0)
    .filter((device) => {
      if (!search) {
        return true;
      }

      const aggregate = [
        String(device.id),
        device.imei || "",
        device.serial || "",
        device.display || "",
        device.model || ""
      ]
        .join(" ")
        .toLowerCase();

      return aggregate.includes(search);
    })
    .sort((a, b) => {
      const aKey = a.imei || String(a.id);
      const bKey = b.imei || String(b.id);
      return aKey.localeCompare(bKey, undefined, { sensitivity: "base" });
    });

  return res.json({ data: filteredDevices });
});

app.get(
  "/api/devices/company/:companyId/installed",
  requireAuth,
  requireAdmin,
  async (req, res) => {
    const companyId = Number(req.params.companyId);
    const search = String(req.query?.search || "").trim().toLowerCase();

    if (!Number.isInteger(companyId) || companyId <= 0) {
      return res.status(400).json({ message: "Valid companyId is required." });
    }

    const statuses = ["installed", "client"];
    const collected = [];

    for (const status of statuses) {
      let page = 1;
      let totalPages = 1;

      do {
        const endpoint =
          `/devices?status=${encodeURIComponent(status)}&limit=100&page=${page}` +
          (search ? `&query=${encodeURIComponent(search)}` : "");

        const response = await crmFetch(req, endpoint, { method: "GET" });
        if (!response.ok) {
          return sendUpstreamError(
            res,
            response,
            "Unable to fetch installed company devices."
          );
        }

        const devices = normalizeList(response.payload)
          .map((item) => {
            const directCompanyId = Number(item?.companyId);
            const relatedCompanyId = Number(item?.related?.id);
            const relatedType = String(item?.related?.type || "").toLowerCase();
            const relatedCarIdRaw = Number(item?.related?.id);
            const relatedCarId =
              relatedType === "car" && Number.isInteger(relatedCarIdRaw)
                ? relatedCarIdRaw
                : null;
            const registrationNumber =
              toOptionalString(
                item?.carNumber || item?.registrationNumber || item?.registrationNr
              ) || null;

            return {
              id: Number(item?.id),
              imei: item?.imei || null,
              serial: item?.serial || null,
              model: item?.model || null,
              modelCode: item?.modelCode || null,
              modelVersion: item?.modelVersion || null,
              productCode: item?.productCode || null,
              status: item?.status || status,
              display: item?.display || null,
              registrationNumber,
              relatedCarId,
              companyId: Number.isInteger(directCompanyId)
                ? directCompanyId
                : relatedType === "company" && Number.isInteger(relatedCompanyId)
                  ? relatedCompanyId
                  : null
            };
          })
          .filter((device) => Number.isInteger(device.id) && device.id > 0)
          .filter((device) => device.companyId === companyId);

        collected.push(...devices);

        const pagination = getPaginationMeta(response.payload);
        totalPages = pagination.totalPages;
        page += 1;
      } while (page <= totalPages && page <= 30);
    }

    const deduplicated = Array.from(
      new Map(collected.map((device) => [device.id, device])).values()
    );

    const carRegistrationLookup = new Map();
    const withRegistration = await Promise.all(
      deduplicated.map(async (device) => {
        let registrationNumber = device.registrationNumber;

        if (!registrationNumber && Number.isInteger(device.relatedCarId) && device.relatedCarId > 0) {
          const existingPromise = carRegistrationLookup.get(device.relatedCarId);
          const fetchPromise =
            existingPromise ||
            (async () => {
              const carResponse = await crmFetch(req, `/cars/${device.relatedCarId}`, {
                method: "GET"
              });

              if (!carResponse.ok) {
                return "";
              }

              const carData = carResponse.payload?.data || carResponse.payload || {};
              return toOptionalString(
                carData?.carNumber ||
                  carData?.registrationNumber ||
                  carData?.registrationNr
              );
            })();

          if (!existingPromise) {
            carRegistrationLookup.set(device.relatedCarId, fetchPromise);
          }

          registrationNumber = await fetchPromise;
        }

        return {
          id: device.id,
          imei: device.imei,
          serial: device.serial,
          model: device.model,
          modelCode: device.modelCode,
          modelVersion: device.modelVersion,
          productCode: device.productCode,
          status: device.status,
          display: device.display,
          companyId: device.companyId,
          registrationNumber: registrationNumber || null
        };
      })
    );

    const filtered = withRegistration
      .filter((device) => {
        if (!search) {
          return true;
        }

        const aggregate = [
          String(device.id),
          device.imei || "",
          device.serial || "",
          device.display || "",
          device.model || "",
          device.registrationNumber || ""
        ]
          .join(" ")
          .toLowerCase();

        return aggregate.includes(search);
      })
      .sort((a, b) => {
        const aKey = a.registrationNumber || a.imei || String(a.id);
        const bKey = b.registrationNumber || b.imei || String(b.id);
        return aKey.localeCompare(bKey, undefined, { sensitivity: "base" });
      });

    return res.json({ data: filtered });
  }
);

app.get(
  "/api/devices/company/:companyId/find-by-imei",
  requireAuth,
  async (req, res) => {
    const companyId = Number(req.params.companyId);
    const searchTerm = String(
      req.query?.query || req.query?.imei || req.query?.serial || ""
    ).trim();

    if (!Number.isInteger(companyId) || companyId <= 0) {
      return res.status(400).json({ message: "Valid companyId is required." });
    }

    if (!searchTerm || searchTerm.length < 3) {
      return res
        .status(400)
        .json({ message: "IMEI or serial value is required." });
    }

    const stockResponse = await crmFetch(
      req,
      `/devices/companies/${companyId}/stock`,
      { method: "GET" }
    );

    if (!stockResponse.ok) {
      return sendUpstreamError(
        res,
        stockResponse,
        "Unable to fetch company stock devices."
      );
    }

    const stockDevices = normalizeList(stockResponse.payload);
    const normalizeIdentifier = (value) =>
      String(value || "")
        .replace(/\s+/g, "")
        .toLowerCase();
    const normalizedSearchTerm = normalizeIdentifier(searchTerm);
    const matchesIdentifier = (value) =>
      normalizeIdentifier(value) === normalizedSearchTerm;

    // ponytail: single stock pass; if stock payload stops exposing identifiers, add a bounded detail scan fallback.
    const stockInfo = stockDevices.find((item) => {
      const display = String(item?.display || "").trim();
      const displayImei = extractImeiFromText(display);

      return (
        matchesIdentifier(item?.imei) ||
        matchesIdentifier(item?.serial) ||
        matchesIdentifier(displayImei) ||
        matchesIdentifier(display)
      );
    });

    if (!stockInfo) {
      return res.status(404).json({
        message: "No matching IMEI or serial in this customer warehouse."
      });
    }

    const selectedId = Number(stockInfo.id);
    if (!Number.isInteger(selectedId) || selectedId <= 0) {
      return res.status(404).json({
        message: "No matching IMEI or serial in this customer warehouse."
      });
    }

    const detailsResponse = await crmFetch(req, `/devices/${selectedId}`, {
      method: "GET"
    });
    const detail = detailsResponse.ok ? detailsResponse.payload?.data || {} : {};

    const selectedDevice = {
      id: selectedId,
      imei:
        detail?.imei ||
        stockInfo?.imei ||
        extractImeiFromText(stockInfo?.display) ||
        null,
      serial: detail?.serial || stockInfo?.serial || null,
      model: stockInfo?.model || detail?.model || null,
      modelCode: stockInfo?.modelCode || detail?.modelCode || null,
      modelVersion: stockInfo?.modelVersion || detail?.modelVersion || null,
      productCode: detail?.productCode || stockInfo?.productCode || null,
      status: detail?.status || stockInfo?.status || null,
      display: stockInfo?.display || null,
      location: stockInfo?.location || null,
      locationDisplay: stockInfo?.locationDisplay || null
    };

    selectedDevice.cameraCapability = await resolveCameraCapability(req, selectedDevice);

    return res.json({
      found: true,
      data: selectedDevice
    });
  }
);

app.get("/api/device-status/:deviceId", requireAuth, async (req, res) => {
  const deviceId = String(req.params.deviceId || "").trim();
  if (!deviceId) {
    return res.status(400).json({ message: "Device ID is required." });
  }

  const response = await crmFetch(
    req,
    `/public-tool/device-test/${encodeURIComponent(deviceId)}`,
    { method: "GET" }
  );

  if (!response.ok) {
    if (looksLikeDeviceNotInstalled(response.payload)) {
      return res.json({
        data: {
          installed: false,
          gps: false,
          fuel: false,
          tachoAvailable: false,
          recentDataWithinTolerance: false,
          lastDataReceived: null,
          raw: response.payload
        }
      });
    }

    return sendUpstreamError(res, response, "Unable to run device status check.");
  }

  const data = response.payload?.data || {};
  const recentDataWithinTolerance = isLastDataRecent(data?.last_data_received);
  const gprs = normalizeSignalValue(data?.main?.gprs);
  const gpsDirect = normalizeSignalValue(data?.main?.gps);
  const gpsInput =
    normalizeSignalValue(data?.inputs?.GPS?.value) ||
    normalizeSignalValue(data?.inputs?.GNSS?.value) ||
    normalizeSignalValue(data?.inputs?.LAT?.value) ||
    normalizeSignalValue(data?.inputs?.LNG?.value);
  const gps = gpsDirect || gpsInput || (gprs && recentDataWithinTolerance);

  const fuel =
    normalizeSignalValue(data?.other?.sensor_fuel) ||
    normalizeSignalValue(data?.can?.can_fuel) ||
    normalizeSignalValue(data?.can?.can_total_fuel);

  return res.json({
    data: {
      installed: true,
      gps,
      fuel,
      tachoAvailable: Boolean(data?.tacho_test_available),
      recentDataWithinTolerance,
      lastDataReceived: data?.last_data_received || null,
      raw: data
    }
  });
});

app.get("/api/device-tacho/:deviceId", requireAuth, async (req, res) => {
  const deviceId = String(req.params.deviceId || "").trim();
  if (!deviceId) {
    return res.status(400).json({ message: "Device ID is required." });
  }

  const response = await crmFetch(
    req,
    `/public-tool/device-tacho/${encodeURIComponent(deviceId)}`,
    { method: "GET" }
  );

  if (!response.ok) {
    if (looksLikeDeviceNotInstalled(response.payload)) {
      return res.json({
        data: {
          installed: false,
          success: false,
          lastDataReceived: null,
          inputs: {},
          raw: response.payload
        }
      });
    }

    return sendUpstreamError(res, response, "Unable to run tacho test.");
  }

  const data = response.payload?.data || {};

  return res.json({
    data: {
      installed: true,
      success: Boolean(data?.tacho_connection_test),
      lastDataReceived: data?.last_data_received || null,
      inputs: data?.inputs || {},
      raw: data
    }
  });
});

app.post("/api/installations/complete", requireAuth, async (req, res) => {
  const companyId = Number(req.body?.companyId);
  const deviceId = Number(req.body?.deviceId);
  const licensePlate = toOptionalString(req.body?.licensePlate);
  const vinNumber = toOptionalString(req.body?.vinNumber);
  const carLabel = licensePlate;
  const vehicleType = toOptionalString(req.body?.vehicleType);
  const notes = toOptionalString(req.body?.notes);
  const additionalFields = toAdditionalInstallFields(req.body?.additionalFields);

  const omittedInstallFields = new Set([
    "carLabel",
    "carNickname",
    "presetId",
    "mappingPresetId"
  ]);

  if (!Number.isInteger(companyId) || companyId <= 0) {
    return res.status(400).json({ message: "Valid companyId is required." });
  }

  if (!Number.isInteger(deviceId) || deviceId <= 0) {
    return res.status(400).json({ message: "Valid deviceId is required." });
  }

  if (licensePlate.length < 2) {
    return res
      .status(400)
      .json({ message: "License plate is required (minimum 2 characters)." });
  }

  if (vinNumber && vinNumber.length < 6) {
    return res
      .status(400)
      .json({ message: "VIN must be at least 6 characters when provided." });
  }

  const installOptionsResponse = await crmFetch(req, "/cars/options", {
    method: "GET"
  });

  if (!installOptionsResponse.ok) {
    return sendUpstreamError(
      res,
      installOptionsResponse,
      "Unable to fetch install requirements."
    );
  }

  const installOptions = normalizeInstallOptions(installOptionsResponse.payload);

  const payload = {
    companyId,
    boxId: deviceId,
    carNumber: licensePlate,
    carLabel,
    ...additionalFields
  };

  if (vinNumber) {
    payload.vinNumber = vinNumber;
  }

  if (vehicleType) {
    payload.vehicleType = vehicleType;
  }

  if (notes) {
    payload.notes = notes;
  }

  const adjusterId = Number(req.session.user?.id);
  if (Number.isInteger(adjusterId) && adjusterId > 0) {
    payload.adjusterId = adjusterId;
  }

  const requiredFieldsInstall = installOptions.requiredFieldsInstall.filter(
    (fieldName) => !omittedInstallFields.has(fieldName)
  );

  for (const fieldName of requiredFieldsInstall) {
    const value = payload[fieldName];
    const missing =
      value === undefined ||
      value === null ||
      (typeof value === "string" && !value.trim()) ||
      (typeof value === "number" && !Number.isFinite(value));

    if (missing) {
      return res.status(400).json({
        message: `Required install field is missing: ${fieldName}`,
        requiredFieldsInstall
      });
    }
  }

  const response = await crmFetch(req, "/cars", {
    method: "POST",
    body: payload
  });

  if (!response.ok) {
    return sendUpstreamError(res, response, "Unable to complete installation.");
  }

  return res.json({
    success: true,
    data: response.payload?.data || null,
    submitted: {
      companyId,
      deviceId,
      licensePlate,
      vinNumber,
      vehicleType,
      notes,
      additionalFields
    },
    requiredFieldsInstall
  });
});

const publicDir = path.join(__dirname, "public");
app.use(express.static(publicDir));

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api")) {
    return next();
  }
  return res.sendFile(path.join(publicDir, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Installer portal running at http://localhost:${PORT}`);
});
